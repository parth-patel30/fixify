<?php


echo "his is the home page";

?>