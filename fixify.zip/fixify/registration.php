<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Fixify</title>
  <link rel="icon" type="image/x-icon" href="fixify12.png">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
    }

    .container {
      background-color: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      max-width: 400px;
      width: 100%;
      margin: 10px auto; 
      text-align: center; 
    }

    form {
      display: flex;
      flex-direction: column;
      align-items: center; 
    }

    label {
      margin-bottom: 5px;
      text-align: center; 
    }

    input,
    textarea,
    select,
    button {
      margin-bottom: 15px;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 4px;
      width: 100%;
      box-sizing: border-box; 
    }

    .password-container {
      position: relative;
      width: 100%;
    }

    .password-container input {
      width: 100%;
      padding-right: 40px; /* Add padding to make room for the icon */
    }

    .password-container .toggle-password {
      position: absolute;
      right: 10px;
      top: 50%;
      transform: translateY(-79%);
      cursor: pointer;
      font-size: 18px;
      color: #555;
    }

    .header {
      display: flex;
      justify-content: space-between; 
      align-items: center;
      padding: 10px 20px;
      background-color: rgb(33, 37, 41);
      color: white;
      width: calc(100% - 20px); 
      position: fixed;
      top: 0;
      z-index: 1000;
    }

    .header-text {
      font-size: 30px;
      text-shadow: 2px 2px 4px white;
    }
    .abcd {
      padding-top: 10%;
      padding-right: 50%;
      text-decoration: none;
    }
    .btn {
      font-size: 18px;
      color: white;
      background: #343a40;
    }

    .btn:hover {
      transition: background 1s ease-in-out; 
      color: black;
      background: #ffffff; 
      border-radius: 20px;
    }

    .btn a {
      text-decoration: none; 
      color: inherit; 
    }

    .btn1 {
      font-size: 18px;
      transition: background 1s ease-in-out; 
      color: white;
      background: #343a40;
    }

    .btn1:hover {
      background: white; 
      color: black;
    }

    .error-message {
      color: red;
      font-size: 12px;
      margin-top: -10px;
      margin-bottom: 10px;
      text-align: left;
      display: none;
    }
  </style>
</head>
<body>

<div class="header">
  <div class="header-text">Fixify</div>
  <form class="d-flex"><div class="abcd">
    <button class="btn"><a href="index.php" style="text-decoration: none; color: inherit;">Home</a></button></div>
  </form>
</div>
<br><br>
<br><br><br>
<div class="container">
  <div style="font-size: 20px; margin-top: 9px;">Registration</div><br>
  <form id="registrationForm" action="process.php" method="post">

    <label for="username">Username:</label>
    <input type="text" id="username" name="username" placeholder="Enter User Name" pattern="[A-Za-z]+" title="Username must contain only characters" required>
    <div id="usernameError" class="error-message">Username must contain only characters</div>

    <label for="email">Email:</label>
    <input type="email" id="email" name="email" placeholder="Enter E-mail" pattern="^[^\s@]+@[^\s@]+\.[^\s@]+$" title="Please enter a valid email address" required>
    <div id="emailError" class="error-message">Please enter a valid email address</div>

    <label for="phoneno">Phone Number:</label>
    <input type="tel" id="phoneno" name="phoneno" placeholder="Enter Phone Number" pattern="^\d{10}$" title="Phone number must be exactly 10 digits" maxlength="10" required>
    <div id="phonenoError" class="error-message">Phone number must be exactly 10 digits</div>

     <label for="address">Address:</label>
    <textarea id="address" name="address"  required></textarea>
    <div id="addressError" class="error-message">Address is required</div>

    <label for="gender">Gender:</label>
    <select id="gender" name="gender" required>
      <option value="male">Male</option>
      <option value="female">Female</option>
    </select>
    <div id="genderError" class="error-message">Gender is required</div>

    <label for="password">Password:</label>
    <div class="password-container">
      <input type="password" id="password" name="password" placeholder="Enter Password" pattern="^(?=.*\d).{8,15}$" title="Password must be between 8 to 15 characters and contain at least one number" required>
      <span class="toggle-password" onclick="togglePasswordVisibility()">👁️</span>
    </div>
    <div id="passwordError" class="error-message">Password must be between 8 to 15 characters and contain at least one number</div>

    <button type="submit" id="nextButton" class="btn">Next</button>
  </form>
</div>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    const registrationForm = document.getElementById('registrationForm');
    const nextButton = document.getElementById('nextButton');

    nextButton.addEventListener('click', function (event) {
      event.preventDefault(); // Prevent default form submission

      if (validateForm()) {
        registrationForm.submit();
      }
    });

    // Real-time validation event listeners
    document.getElementById('username').addEventListener('input', function() {
      validateField('username');
    });

    document.getElementById('email').addEventListener('input', function() {
      validateField('email');
    });

    document.getElementById('phoneno').addEventListener('input', function() {
      validateField('phoneno');
    });
  
    document.getElementById('address').addEventListener('input', function() {
      validateField('address');
    });

    document.getElementById('password').addEventListener('input', function() {
      validateField('password');
    });
  });

  function validateForm() {
    var isValid = true;

    if (!validateField('username')) isValid = false;
    if (!validateField('email')) isValid = false;
    if (!validateField('phoneno')) isValid = false;
    if (!validateField('address')) isValid = false;
    if (!validateField('password')) isValid = false;

    return isValid;
  }

  function validateField(fieldId) {
    var field = document.getElementById(fieldId);
    var errorDiv = document.getElementById(fieldId + 'Error');
    if (field.checkValidity()) {
      errorDiv.style.display = 'none';
      return true;
    } else {
      errorDiv.style.display = 'block';
      return false;
    }
  }

  function togglePasswordVisibility() {
    const passwordField = document.getElementById('password');
    const toggleIcon = document.querySelector('.toggle-password');
    if (passwordField.type === 'password') {
      passwordField.type = 'text';
      toggleIcon.textContent = '🙈';
    } else {
      passwordField.type = 'password';
      toggleIcon.textContent = '👁️';
    }
  }
</script>

</body>
</html>
