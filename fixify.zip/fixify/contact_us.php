<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$database = "fixify";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Escape user inputs for security
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $subject = $conn->real_escape_string($_POST['subject']);
    $message = $conn->real_escape_string($_POST['message']);

    // Insert data into the database
    $sql = "INSERT INTO contact(name, email, subject, message) VALUES ('$name', '$email', '$subject', '$message')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Fixify</title>
  <link rel="icon" type="image/x-icon" href="fixify12.png">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
    }

    .container {
      background-color: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      max-width: 600px;
      width: 100%;
      margin: 50px auto; 
      text-align: center; 
    }

    .header {
      display: flex;
      justify-content: space-between; 
      align-items: center;
      padding: 10px 20px;
      margin-right: 0;
      background-color: rgb(33, 37, 41);
      color: white;
      width: calc(100% ); 
      position: fixed;
      top: 0;
      z-index: 1000;
    }

    .header-text {
      font-size: 30px;
      text-shadow: 2px 2px 4px white;
    }

    .btn {
      font-size: 18px;
      color: white;
      background: #343a40;
      border-radius: 20px;
    }

    .btn:hover {
      background: #ffffff; 
      color: black;
    }

    .btn a {
      text-decoration: none; 
      color: inherit; 
    }

    h1 {
      color: #343a40;
      text-align: center;
      margin-bottom: 10px;
    }

    /* Placeholder styles */
    .form-floating input.form-control:focus~label,
    .form-floating textarea.form-control:focus~label,
    .form-floating input.form-control:not(:placeholder-shown)~label,
    .form-floating textarea.form-control:not(:placeholder-shown)~label {
      color: #6c757d;
      font-size: 0.875rem;
      transform: translateY(-1.5rem) scale(0.85);
      transform-origin: top left;
      transition: all 0.1s ease-in-out;
    }
  </style>
</head>
<body>
<div class="header">
  <div class="header-text">Fixify</div>
  <form class="d-flex">
    <div class="abcd">
      <button class="btn"><a href="index.php" style="text-decoration: none; color: inherit;">Home</a></button>
    </div>
  </form>
</div><br>
<div class="container">
  <h1>Contact Us</h1>
  <form id="contactForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
    <div class="mb-3 form-floating">
      <input type="text" class="form-control" id="name" name="name" placeholder=" " required>
      <label for="name" class="form-label">Your Name</label>
    </div>
    <div class="mb-3 form-floating">
      <input type="email" class="form-control" id="email" name="email" placeholder=" " required>
      <label for="email" class="form-label">Your Email</label>
    </div>
    <div class="mb-3 form-floating">
      <input type="text" class="form-control" id="subject" name="subject" placeholder=" " required>
      <label for="subject" class="form-label">Subject</label>
    </div>
    <div class="mb-3 form-floating">
      <textarea class="form-control" id="message" name="message" rows="5" placeholder=" " required></textarea>
      <label for="message" class="form-label">Message</label>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
  <?php
  if (isset($_POST['name'])) {
    echo '<div class="alert alert-success mt-3" role="alert">
            Your message has been sent successfully!
          </div>';
  }
  ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  document.getElementById('contactForm').addEventListener('submit', function(event) {
    const subject = document.getElementById('subject').value;
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    if (subject.trim() === '' || name.trim() === '' || email.trim() === '' || message.trim() === '') {
      event.preventDefault();
      alert('Please fill in all fields.');
    }
  });
</script>
</body>
</html>
