<?php
session_start();
if (isset($_SESSION['message']) && !empty($_SESSION['message'])) {
  echo "<script>alert('{$_SESSION['message']}');</script>";
  unset($_SESSION['message']);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Fixify</title>
  <link rel="icon" type="image/x-icon" href="fixify12.png">
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    .btn {
      transition: background 1s ease-in-out; 
      color: white;
      border-radius: 20px;
    }

    .btn:hover {
      background: #ffffff; 
    }

    
    .btn a {
      text-decoration: none; 
      color: inherit; 
    }
.abcd{
padding-left: 49%;

}
    .btn1 {
      
      font-size: 18px;
      transition: background 1s ease-in-out; 
      color: black;
      border-radius: 10px;
    }

    .btn1:hover {
      background: #343a40; 
      color: white;
    }

    /*   slide*/
   .mySlides1 { display: none; }
    img { vertical-align: middle; 
      height: 570px;
    }
    .slideshow-container { position: relative; margin: auto; }

    .prev, .next {
      cursor: pointer;
      position: absolute;
      top: 50%;
      width: auto;
      padding: 16px;
      margin-top: -22px;
      color: white;
      font-weight: bold;
      font-size: 18px;
      transition: 0.6s ease;
      border-radius: 0 3px 3px 0;
      user-select: none;
    }

    .next { right: 0; border-radius: 3px 0 0 3px; }

    .prev:hover, .next:hover {
      background-color: #f1f1f1;
      color: black;
    }
    .subhead12{
      font-family: "Lucida Console";
      padding-top: 10px;
      padding-bottom: 10px;
      background-color: #343a40;
      color:white;
      width:100%;
      font-size: 22px;
      text-align: center;
    }
    /* div of rows*/

    .column {
  float: left;
  width: 33%;
  padding: 20px;
  height: 300px; 
}

.row:after {
  content: "";
  display: table;
  clear: both;
}
.img1{
height: 80px;

}
 .foot{
      font-family: "Lucida Console";
      padding-top: 10px;
      margin-top:1%; 
      background-color: #343a40;
      color:white;
      width:100%;
      overflow: hidden; 
    }

@media screen and (max-width: 600px) {
  .column {
    width: 100%;
  }
  
}

@media screen and (max-width: 768px) {
  .foot {
    margin-top: 120px;
  }
}
.password-container {
      position: relative;
      width: 100%;
    }

    .password-container input {
      width: 100%;
      padding-right: 40px; /* Add padding to make room for the icon */
    }

    .password-container .toggle-password {
      position: absolute;
      right: 10px;
      top: 50%;
      transform: translateY(-49%);
      cursor: pointer;
      font-size: 18px;
      color: #555;
    }
  .email-link {
      color: white; 
      text-decoration: none; 
    }

    .email-link:hover {
      text-decoration: underline; 
    }
    .forgot{
      padding: 2px;
      text-decoration: none;
      font-size: 18px;
       transition: background 1s ease-in-out; 
        background-color:  #f1f1f1;
      color: black;
      border:2px solid black;
      border-radius: 10px;
    }
     .forgot:hover {
     
      background-color: #343a40;
     color:white;
    }


    /* Placeholder styles */
    .form-floating input.form-control:focus~label,
    .form-floating textarea.form-control:focus~label,
    .form-floating input.form-control:not(:placeholder-shown)~label,
    .form-floating textarea.form-control:not(:placeholder-shown)~label {
      color: #6c757d;
      font-size: 0.875rem;
      transform: translateY(-1.5rem) scale(0.85);
      transform-origin: top left;
      transition: all 0.1s ease-in-out;
    }

    .form-floating {
      position: relative;
    }

    .form-floating input.form-control,
    .form-floating textarea.form-control {
     
      height: auto;
    }

    .form-floating label {
      position: absolute;
      top: 0;
      left: 0.75rem;
      pointer-events: none;
      transform-origin: top left;
      transition: all 0.1s ease-in-out;
      color: black;
    }

/* Webkit scrollbar */
::-webkit-scrollbar {
  width: 10px;
}

/* Track */
::-webkit-scrollbar-track {
  background: #343a40; /* Dark background color */
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: white; /* Light color for the scrollbar handle */
  border-radius: 20px; /* Rounded corners */
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background:lightgrey; /* Darker color on hover */
}


  </style>
</head>
<body>

<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="javascript:void(0)">
      <div style="font-size: 30px;text-shadow: 2px 2px 4px white;padding-left:1%;">Fixify</div>
    </a>
    
    </button>
    <form class="d-flex">
      <!-- Updated registration button with styled link -->
      <button class="btn" type="button"><a href="registration.php">Registration</a></button>&nbsp;
      <button class="btn" type="button" data-bs-toggle="modal" data-bs-target="#signupModal">Login</button>
    </form>
  </div>
</nav>

<!-- Slides  -->
<div class="slideshow-container">
  <div class="mySlides1">
    <img src="./img/s1.jpg" style="width:100%">
  </div>

  <div class="mySlides1">
    <img src="./img/s2.jpg" style="width:100%">
  </div>

  <div class="mySlides1">
    <img src="./img/s3.jpg" style="width:100%">
  </div>

  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>
<!--- menu after header -->
<div class="subhead12">
ABOUT HOUSEHOLD SERVICES 
</div>

<br><br>
<!--- activity -->

 <div id="1">
     <section id="boxes">
      <div class="container" >
        <div class="column">
          <img src="./img/cicon.png" class="img1">
          <br/>
          <h3>Time-Saving</h3>
          <br/>
          <p>You free up valuable time to focus on what truly matters to you.</p>
        </div>
        <div class="column">
          <img src="./img/images.png" class="img1">
          <br/>
          <h3>HOME MANAGING</h3>
          <br/>
          <p>You make managing of services a house based on your task.</p>
        </div>
        <div class="column">
          <img src="./img/504652.png" class="img1">
          <br/>
          <h3>Easy Scheduling</h3>
          <br/>
          <p>You can schedule services at your preferred date and time</p>
        </div>
      </div>
</section>
</div>
<br><br><br><br><br>
<!-- footer -->
<footer class="">


  <section class="">
    <div class="foot">
    <div class="container text-center text-md-start mt-5">
      <div class="row mt-3">
        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
          <h6 class="">
            <div style="font-size: 30px;text-shadow: 2px 2px 4px white;padding-left:1%;">Fixify</div>
          </h6>
          <p>
          
          </p>
        </div>
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
          <h6 class="text-uppercase fw-bold mb-4">
            Apply For Service Partner
          </h6>
          <p>
            <a href="registrationpartner.php" class="text-reset">Apply</a>
          </p>
          
        </div>
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
          <h6 class="text-uppercase fw-bold mb-4">
           For Contact    
          </h6>
          <p>
            <a href="contact_us.php" class="text-reset">Click here</a>
          
            
          </p>
          
        </div>
      </div>
    </div>
  </section>

  <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
    © 2024 Copyright:
    <a class="text-reset fw-bold" href="">Fixify</a>
  </div>
</footer>

</div>


<!-- popup login box-->
<div class="modal fade" id="signupModal" tabindex="-1" aria-labelledby="signupModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="signupModalLabel">Login</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="post" action="login.php">
          <div class="form-floating mb-3">
            <input type="email" placeholder="Enter Email" class="form-control" id="email" name="email" aria-describedby="emailHelp">
            <label for="email">Email</label>
          </div>
          <div class="form-floating mb-3 password-container">
            <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password" pattern="^(?=.*\d).{8,15}$" title="Password must be between 8 to 15 characters and contain at least one number" required>
            <label for="password">Password</label>
            <span class="toggle-password" onclick="togglePasswordVisibility()">👁️</span>
          </div>
          <div class="abcd">
            <a class="forgot" href="forgot_password.php">Reset Password</a>
            &nbsp;&nbsp;<button type="submit" class="btn1" name="login">Login</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script>

  let slideIndex = 0;
  showSlides();

  function plusSlides(n) {
    showSlides(slideIndex += n);
  }

  function showSlides() {
    let i;
    let slides = document.getElementsByClassName("mySlides1");
    if (slideIndex >= slides.length) { slideIndex = 0; }
    if (slideIndex < 0) { slideIndex = slides.length - 1; }
    for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
    }
    slides[slideIndex].style.display = "block";
  }

  setInterval(function() {
    plusSlides(1);
  }, 5000); 
   function togglePasswordVisibility() {
    const passwordField = document.getElementById('password');
    const toggleIcon = document.querySelector('.toggle-password');
    if (passwordField.type === 'password') {
      passwordField.type = 'text';
      toggleIcon.textContent = '🙈';
    } else {
      passwordField.type = 'password';
      toggleIcon.textContent = '👁️';
    }
  }
</script>


</body>
</html>
