<?php
session_start();

// Define the generateRandomOtp function
function generateRandomOtp() {
    return strval(rand(100000, 999999));
}

$selectedServices = isset($_SESSION['selected_services']) ? $_SESSION['selected_services'] : [];

// Check if selectedServices is an array and not empty
if (is_array($selectedServices) && !empty($selectedServices)) {
    // Proceed with processing
} else {
    echo "Error: Selected services must be an array and not empty.";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST["username"];
    $email = $_POST["email"];
    $phoneno = $_POST["phoneno"];
    $address = $_POST["address"];
    $gender = $_POST["gender"];
    $password = $_POST["password"];
    $expirence = isset($_POST["experience"]) ? $_POST["experience"] : ""; // Add placeholder value

    // File upload handling
    $targetDir = "partner/img/doc/";
    $fileName = basename($_FILES["govtId"]["name"]);
    $targetFilePath = $targetDir . $fileName;
    $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

    if (move_uploaded_file($_FILES["govtId"]["tmp_name"], $targetFilePath)) {
        // Store form data and file path in session
        $_SESSION['username'] = $username;
        $_SESSION['email'] = $email;
        $_SESSION['phoneno'] = $phoneno;
        $_SESSION['address'] = $address;
        $_SESSION['gender'] = $gender;
        $_SESSION['password'] = $password;
        $_SESSION['govtId'] = $targetFilePath;
        $_SESSION['experience'] = $expirence; // Store experience in session

        // Placeholder for selectedExperience, update with actual value

        // Generate OTP and send email
        $otp = generateRandomOtp();
        $_SESSION['otp'] = $otp;

        // Call the sendOtpToEmail function
        if (sendOtpToEmail($email, $username, $otp)) {
            header("Location: verify_otppartner.php");
            exit;
        } else {
            echo "Failed to send OTP. Please try again.";
        }
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

function sendOtpToEmail($email, $username, $otp) {
    $apiKey = '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';

    $url = "https://api.sendinblue.com/v3/smtp/email";

    $message = "<pre> 
    Dear <b>$username</b>,

    Welcome to you the fixify, 
    for your Account Verification  
    OTP is:  <b>$otp</b>
    </pre>";

    $htmlContent = "<html><body><p>$message</p></body></html>";

    $data = [
        'subject' => 'Verification',
        'sender' => ['name' => 'Fixify', 'email' => 'fixify@email.com'],
        'to' => [['email' => $email, 'name' => $username]],
        'params' => ['otp' => $otp, 'message' => $message],
        'htmlContent' => $htmlContent,
        'textContent' => $message,
    ];

    $ch = curl_init($url);

    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'api-key: ' . $apiKey,
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo 'Curl error: ' . curl_error($ch);
        return false;
    }

    curl_close($ch);

    $jsonResponse = json_decode($response, true);
    if ($jsonResponse && isset($jsonResponse['messageId'])) {
        return true;
    } else {
        echo 'Failed to send email. Sendinblue response: ' . $response;
        return false;
    }
}
?>
