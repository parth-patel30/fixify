-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2024 at 06:01 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fixify`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `id` int(11) DEFAULT NULL,
  `serviceid` int(11) DEFAULT NULL,
  `service_name` varchar(255) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `status` varchar(20) DEFAULT '',
  `discount` decimal(10,2) DEFAULT 0.00,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `id`, `serviceid`, `service_name`, `total_price`, `quantity`, `status`, `discount`, `notes`) VALUES
(34, 60, 11, 'tv repair', 1500.00, 1, '', 0.00, NULL),
(37, 60, 11, 'tv repair', 1500.00, 1, '', 0.00, NULL),
(64, 61, 11, 'tv repair', 900.00, 1, '', 0.00, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `subject`, `message`, `submission_date`) VALUES
(4, 'amit', 'parthpatelk3011@gmail.com', 'summer intership ends on 10 Aug', 'keh feg fyeg iyegf iusg sg isg', '2024-05-14 10:30:16');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `message`, `created_at`) VALUES
(2, 61, 'New order placed successfully', '2024-04-24 16:56:58'),
(3, 61, 'New order placed successfully', '2024-05-21 15:42:48');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `serviceid` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `address` varchar(255) NOT NULL,
  `select_date` varchar(100) NOT NULL,
  `select_time` varchar(50) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `total_price` varchar(50) NOT NULL,
  `paymentmode` varchar(50) DEFAULT 'By Card',
  `paymentstatus` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `serviceid`, `userid`, `address`, `select_date`, `select_time`, `quantity`, `total_price`, `paymentmode`, `paymentstatus`, `status`, `order_date`) VALUES
(5, 9, 61, 'd/40,maruti homes', '2024-04-26', '10:30 AM', '2', '2510', 'By Card', 'successfully', '1', '2024-05-21 10:24:28'),
(6, 11, 61, 'd/4011  ,maruti homes', '2024-05-22', '10:00 AM', '1', '900', 'By Card', 'successfully', '0', '2024-05-21 15:42:48');

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `rating` int(11) DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`id`, `order_id`, `user_id`, `service_id`, `rating`, `feedback`, `created_at`) VALUES
(1, 5, 61, 9, 3, 'nice nice nice', '2024-04-24 16:57:51');

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `request_id` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `roleid` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`request_id`, `userid`, `roleid`, `title`, `description`, `status`, `created_at`, `updated_at`) VALUES
(28, 60, 2, 'coooo123', 'cooo123 alpha be hello\r\n', 0, '2024-05-21 08:39:09', '2024-05-21 08:50:56'),
(31, 61, 1, 'hello add this services', 'please add this services', 0, '2024-05-21 13:51:59', '2024-05-21 13:51:59');

-- --------------------------------------------------------

--
-- Table structure for table `role_master`
--

CREATE TABLE `role_master` (
  `role_id` int(2) NOT NULL,
  `roles` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role_master`
--

INSERT INTO `role_master` (`role_id`, `roles`) VALUES
(1, 'users'),
(2, 'Partner '),
(3, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `serviceid` int(11) NOT NULL,
  `servicename` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `ratingid` int(11) DEFAULT NULL,
  `feedbackid` int(255) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `status` int(1) NOT NULL,
  `Ratings` int(11) DEFAULT 0,
  `reviews` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`serviceid`, `servicename`, `description`, `image`, `price`, `ratingid`, `feedbackid`, `userid`, `status`, `Ratings`, `reviews`) VALUES
(9, 'ac repair', 'Air conditioning (AC) repair refers to the process of fixing or restoring the functionality of air conditioning systems that have encountered issues or malfunctions. AC repair services are crucial for maintaining comfortable indoor temperatures, especially during hot or humid weather conditions.', 'img/serv/download.jpg', 999.00, 0, 0, 60, 1, 0, 0),
(11, 'tv repair', 'TV Repair Technician - is responsible for interacting with the customer to install the TV as well as diagnose the problem. The individual also needs to assess possible causes of fault reported and rectify problems/faults.', 'img/serv/tvrepair.jpg', 900.00, 0, 0, 60, 1, 0, 0),
(12, 'ac cleaning', 'AC cleaning services are essential maintenance tasks aimed at ensuring the optimal performance and longevity of air conditioning units. These services include a comprehensive inspection and cleaning of the various components of the AC system to remove dirt, dust, and debris that accumulate over time. ', 'img/serv/ac clean.jpeg', 999.00, NULL, NULL, 60, 1, 0, 0),
(13, 'replace tv panel', 'Replacing a TV panel involves the process of removing the damaged or malfunctioning panel from a television set and installing a new one in its place. This service is typically performed by technicians or professionals with expertise in electronics and TV repair.', 'img/serv/tv replace.jpg', 4800.00, NULL, NULL, 60, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `services_master`
--

CREATE TABLE `services_master` (
  `services_id` int(11) NOT NULL,
  `services_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `services_master`
--

INSERT INTO `services_master` (`services_id`, `services_name`) VALUES
(1, 'Electrician'),
(2, 'Plumber'),
(3, 'Salon');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phoneno` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `gender` varchar(10) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` int(1) NOT NULL,
  `doc` varchar(255) NOT NULL,
  `services_id` int(11) NOT NULL,
  `experience` varchar(50) NOT NULL,
  `status` int(1) NOT NULL,
  `available` int(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `phoneno`, `address`, `gender`, `password`, `role_id`, `doc`, `services_id`, `experience`, `status`, `available`, `created_at`) VALUES
(5, 'parth', '186330316040.parth.patel@gmail.com', '8488071606', 'gahsg g ghdsfghf sahf gfyadg h da', 'Male', '$2y$10$FuUtHBXBNeYjE9AL.RUHvuOnnKm0.plpPcjZHwORsAMVtMGWvid5a', 2, 'download.png', 2, '', 0, 1, '2024-03-19 07:51:21'),
(60, 'parth', 'parthpatelk3011@gmail.com', '8488071606', 'maruti Homes', 'Male', '$2y$10$L0lpIu.o1pDJMeeabfuRk.fq.ODHTBfike/ikGVgnAzYfz0nwPZfu', 2, 'pan_card_1565610340828_1572021543426.jpg', 1, '1-3year', 1, 1, '2024-03-22 07:15:08'),
(61, 'parth patel', 'ganak473011@gmail.com', '8488071606', 'd/40,maruti homes', 'Male', '$2y$10$EZ2puE771U3o4uNFok2P1eoEZUgxf/v.xwiKQwWnrrQoJOo.Cyucm', 1, '', 0, '', 1, 1, '2024-03-22 10:18:00'),
(62, 'admin', '211430116515.it.parth@gmail.com', '8488071606', 'maruti complex', 'male', '$2y$10$eHICfg.YUcQ1EGyogF8jT.QYmErABSEdF2PbIL6frmTtaOtZoZXTC', 3, '', 0, '', 3, 3, '2024-05-14 09:20:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `id` (`id`),
  ADD KEY `serviceid` (`serviceid`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `orders_ibfk_1` (`serviceid`),
  ADD KEY `orders_ibfk_2` (`userid`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `service_id` (`service_id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `userid` (`userid`),
  ADD KEY `roleid` (`roleid`);

--
-- Indexes for table `role_master`
--
ALTER TABLE `role_master`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`serviceid`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `services_master`
--
ALTER TABLE `services_master`
  ADD PRIMARY KEY (`services_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_id` (`role_id`),
  ADD KEY `services_id` (`services_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `role_master`
--
ALTER TABLE `role_master`
  MODIFY `role_id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `serviceid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `services_master`
--
ALTER TABLE `services_master`
  MODIFY `services_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`serviceid`) REFERENCES `services` (`serviceid`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`serviceid`) REFERENCES `services` (`serviceid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `ratings`
--
ALTER TABLE `ratings`
  ADD CONSTRAINT `ratings_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `ratings_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `ratings_ibfk_3` FOREIGN KEY (`service_id`) REFERENCES `services` (`serviceid`);

--
-- Constraints for table `requests`
--
ALTER TABLE `requests`
  ADD CONSTRAINT `requests_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `requests_ibfk_2` FOREIGN KEY (`roleid`) REFERENCES `role_master` (`role_id`);

--
-- Constraints for table `services`
--
ALTER TABLE `services`
  ADD CONSTRAINT `services_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role_master` (`role_id`),
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`services_id`) REFERENCES `services_master` (`services_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
