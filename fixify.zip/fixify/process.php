<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $username = $_POST["username"];
    $email = $_POST["email"];
    $phoneno = $_POST["phoneno"];
    $address = $_POST["address"];
    $gender = $_POST["gender"];
    $password = $_POST["password"];

    $otp = generateRandomOtp();

    $_SESSION['username'] = $username;
    $_SESSION['email'] = $email;
    $_SESSION['phoneno'] = $phoneno;
    $_SESSION['address'] = $address;
    $_SESSION['gender'] = $gender;
    $_SESSION['password'] = $password;
    $_SESSION['otp'] = $otp;

    if (sendOtpToEmail($email, $username, $otp)) {
       
        header("Location: verify_otp.php");
        exit;
    } else {
        
        echo "Failed to send OTP. Please try again.";
    }
}

function generateRandomOtp() {
    return strval(rand(100000, 999999));
}

function sendOtpToEmail($email, $username, $otp) {
    
    $apiKey = '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';

     $url = "https://api.sendinblue.com/v3/smtp/email";

    $message = "<pre> 
    Dear <b>$username</b>,

    Welcome to you the fixify, 
    for your Account Verification  
    OTP is:  <b>$otp</b>
    </pre>";

    $htmlContent = "<html><body><p>$message</p></body></html>";

    
    $data = [
        'subject' => 'Verification',
        'sender' => ['name' => 'Fixify', 'email' => 'fixify@email.com'],
        'to' => [['email' => $email, 'name' => $username]],
        'params' => ['otp' => $otp, 'message' => $message],
        'htmlContent' => $htmlContent,
        'textContent' => $message,
    ];

    
    $ch = curl_init($url);

    
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'api-key: ' . $apiKey,
    ]);

    
    $response = curl_exec($ch);

    
    if (curl_errno($ch)) {
        echo 'Curl error: ' . curl_error($ch);
        return false;
    }

    
    curl_close($ch);

    
    $jsonResponse = json_decode($response, true);
    if ($jsonResponse && isset($jsonResponse['messageId'])) {
        return true;
    } else {
        
        echo 'Failed to send email. Sendinblue response: ' . $response;
        return false;
    }
}
?>
