document.addEventListener('DOMContentLoaded', function () {
  const registrationForm = document.getElementById('registrationForm');
  const nextButton = document.getElementById('nextButton');

  nextButton.addEventListener('click', function () {
    
    if (validateForm()) {
      registrationForm.submit();
    }
  });

  function validateForm() {
    var username = document.getElementById('username').value;
    var email = document.getElementById('email').value;
    var phoneno = document.getElementById('phoneno').value;
    var address = document.getElementById('address').value;
    var gender = document.getElementById('gender').value;
    var password = document.getElementById('password').value;

    if (!username || !email || !phoneno || !address || !gender || !password) {
      alert('Please fill in all fields');
      return false;
    }

    // Additional validation logic can be added here

    return true;
  };
