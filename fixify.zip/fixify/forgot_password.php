
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Fixify</title>
  <link rel="icon" type="image/x-icon" href="fixify12.png">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link href= 
"https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" 
          rel="stylesheet"> 
    <script src= 
"https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"> 
    </script> 
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
    }

    .container {
      background-color: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      max-width: 400px;
      width: 100%;
      margin: 10px auto; 
      text-align: center; 
    }

    form {
      display: flex;
      flex-direction: column;
      align-items: center; 
    }

    label {
      margin-bottom: 5px;
      text-align: center; 
    }

    input,
    textarea,
    select,
    button {
      margin-bottom: 15px;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 4px;
      width: 100%;
      box-sizing: border-box; 
    }

   
    .header {
      display: flex;
      justify-content: space-between; 
      align-items: center;
      padding: 10px 20px;
      margin-right: 0;
      background-color: rgb(33, 37, 41);
      color: white;
      width: calc(100% ); 
      position: fixed;
      top: 0;
      z-index: 1000;
    }

    .header-text {
      font-size: 30px;
      text-shadow: 2px 2px 4px white;
    }
.abcd{
  padding-top: 10%;
  padding-right: 50%;
  text-decoration: none;
}
     .btn {

      font-size:18px;
      color:white;
       background: #343a40;
     
    }

    .btn:hover {
      transition: background 1s ease-in-out; 
      color:black;
      background: #ffffff; 
       border-radius: 20px;
    }

    
    .btn a {
      text-decoration: none; 
      color: inherit; 
    }

    .btn1 {
      font-size: 18px;
      transition: background 1s ease-in-out; 
      color:white;
      background: #343a40;
      
    }

    .btn1:hover {
      background: white; 
     color: black;
    }
     .dropdown-menu {
      padding: 10px;
      margin-top: 5px;
      min-width: 180px; 
      justify-content: center;

    }

    .dropdown-menu label {
       
    }

    .dropdown-menu li {
      list-style-type: none; 
    }
  </style>
</head>
<body>
<div class="header" >
  <div class="header-text">Fixify</div>
  <form class="d-flex"><div class="abcd">
    <button class="btn"><a href="index.php" style="text-decoration: none; color: inherit;">Home  </a></button></div>
  </form></div><br><br><br><br>
<div class="container mt-7">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Forgot Password</div>
                <div class="card-body">
                    <?php
                    session_start();
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        $email = $_POST["email"];
                        // Database connection code goes here
                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $dbname = "fixify";

                        $conn = new mysqli($servername, $username, $password, $dbname);
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        // Query to check if email exists in the database
                        $checkEmailQuery = "SELECT * FROM users WHERE email='$email'";
                        $result = $conn->query($checkEmailQuery);

                        if ($result->num_rows == 0) {
                            // Email does not exist in the database
                            echo '<div class="alert alert-danger" role="alert">Email does not exist. Please check your email address.</div>';
                        } else {
                            // Email exists, proceed with generating OTP and redirect to OTP verification
                            $_SESSION['email'] = $email;
                            $otp = generateRandomOtp();
                            $_SESSION['otp'] = $otp;
                            // Call the sendOtpToEmail function
                            if (sendOtpToEmail($email, $otp)) {
                                header("Location: verify_passotp.php");
                                exit;
                            } else {
                                echo "Failed to send OTP. Please try again.";
                            }
                        }

                        $conn->close(); // Close database connection
                    }

                    function generateRandomOtp() {
                        return strval(rand(100000, 999999));
                    }

                    function sendOtpToEmail($email, $otp) {
                          $apiKey = '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';

    $url = "https://api.sendinblue.com/v3/smtp/email";

    $message = "<pre> 
    Dear <b> user</b>,

    Welcome to you the fixify, 
    for reset yout Account password  
    OTP is:  <b>$otp</b>
    </pre>";

    $htmlContent = "<html><body><p>$message</p></body></html>";

    $data = [
        'subject' => 'Reset Password',
        'sender' => ['name' => 'Fixify', 'email' => 'fixify@email.com'],
        'to' => [['email' => $email, 'name' => $username]],
        'params' => ['otp' => $otp, 'message' => $message],
        'htmlContent' => $htmlContent,
        'textContent' => $message,
    ];

    $ch = curl_init($url);

    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'api-key: ' . $apiKey,
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo 'Curl error: ' . curl_error($ch);
        return false;
    }

    curl_close($ch);

    $jsonResponse = json_decode($response, true);
    if ($jsonResponse && isset($jsonResponse['messageId'])) {
        return true;
    } else {
        echo 'Failed to send email. Sendinblue response: ' . $response;
        return false;
    }
                    }
                    ?>
                    <form id="forgotPasswordForm" method="POST" action="forgot_password.php">
                        <div class="form-group">
                            <label for="email">Email Address:</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Send OTP</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
