<?php
session_start();
// Assuming you have a database connection established already
// Replace these values with your actual database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fixify";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['login'])) {
  $email = $_POST['email'];
  $password = $_POST['password'];

  $sql = "SELECT * FROM users WHERE email = '$email'";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $hashed_password = $row['password'];
$role_id = $row['role_id'];

    if (password_verify($password, $hashed_password)) {
       $_SESSION['user_id'] = $row['id'];
      if ($role_id == 1) {
        // User role, redirect to user home page
        header("Location: user/index.php");
        exit();
      } elseif ($role_id == 2) {
        // Partner role, redirect to partner home page
        header("Location: partner/index.php");
        exit();
      } elseif ($role_id == 3) {
        
        header("Location: admin/index.php");
        exit();
      }
    } else {
      // Password is incorrect, redirect back to login page with error message
      $_SESSION['message'] = "Incorrect email or password";
      header("Location: index.php");
      exit();
    }
  } else {
    // User not found, redirect back to login page with error message
    $_SESSION['message'] = "User not found";
    header("Location: index.php");
    exit();
  }
}

$conn->close();
?>