<?php
include "home.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Fixify</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2>Manage Orders </h2>
    <?php
    // Include database connection
    include_once 'db_connect.php';

    // Function to escape HTML and prevent SQL injection
    function cleanInput($input)
    {
        $cleaned = htmlspecialchars(strip_tags($input));
        return $cleaned;
    }

    if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $order_id = cleanInput($_GET['id']);

    // Check if there are related entries in the ratings table
    $sql_check_ratings = "SELECT * FROM ratings WHERE order_id = $order_id";
    $result_check_ratings = mysqli_query($conn, $sql_check_ratings);

    if (mysqli_num_rows($result_check_ratings) > 0) {
        echo '<div class="alert alert-danger">Cannot delete order. There are related entries in the ratings table.</div>';
    } else {
        // No related entries in ratings, proceed with deletion
        $sql_delete = "DELETE FROM orders WHERE order_id = $order_id";
        mysqli_query($conn, $sql_delete);
        echo '<div class="alert alert-success">Order deleted successfully!</div>';
    }
}


    // Handle form submission for editing an order
    if (isset($_POST['save'])) {
        $order_id = cleanInput($_POST['order_id']);
        $address = cleanInput($_POST['address']);
        $select_date = cleanInput($_POST['select_date']);
        $select_time = cleanInput($_POST['select_time']);
        $quantity = cleanInput($_POST['quantity']);
        $total_price = cleanInput($_POST['total_price']);
        $paymentstatus = cleanInput($_POST['paymentstatus']);
        $order_date = date('Y-m-d H:i:s'); // Current timestamp

        $sql_update = "UPDATE orders SET address = '$address', select_date = '$select_date', select_time = '$select_time', 
                       quantity = '$quantity', total_price = '$total_price', paymentstatus = '$paymentstatus', order_date = '$order_date' 
                       WHERE order_id = $order_id";
        mysqli_query($conn, $sql_update);
        echo '<div class="alert alert-success">Order updated successfully!</div>';
    }

    // Fetch orders from the database
    $sql_select = "SELECT * FROM orders";
    $result = mysqli_query($conn, $sql_select);
    ?>
    <table class="table">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Address</th>
                <th>Select Date</th>
                <th>Select Time</th>
                <th>Quantity</th>
                <th>Total Price</th>
                <th>Payment Status</th>
                <th>Order Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['order_id'] . "</td>";
                echo "<td>" . $row['address'] . "</td>";
                echo "<td>" . $row['select_date'] . "</td>";
                echo "<td>" . $row['select_time'] . "</td>";
                echo "<td>" . $row['quantity'] . "</td>";
                echo "<td>" . $row['total_price'] . "</td>";
                echo "<td>" . $row['paymentstatus'] . "</td>";
                echo "<td>" . $row['order_date'] . "</td>";
                echo "<td>
                        <a href='?action=edit&id=" . $row['order_id'] . "' class='btn btn-sm btn-primary'>Edit</a>
                        <a href='?action=delete&id=" . $row['order_id'] . "' class='btn btn-sm btn-danger'>Delete</a>
                      </td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
    <!-- Form for editing an order -->
    <?php
    if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
        $order_id = cleanInput($_GET['id']);
        $sql_fetch = "SELECT * FROM orders WHERE order_id = $order_id";
        $result_edit = mysqli_query($conn, $sql_fetch);
        $row_edit = mysqli_fetch_assoc($result_edit);
        ?>
        <div class="row">
            <div class="col-md-6">
                <form action="" method="POST">
                    <input type="hidden" name="order_id" value="<?php echo $row_edit['order_id']; ?>">
                    <div class="form-group">
                        <label for="address">Address:</label>
                        <input type="text" class="form-control" id="address" name="address" value="<?php echo $row_edit['address']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="select_date">Select Date:</label>
                        <input type="text" class="form-control" id="select_date" name="select_date" value="<?php echo $row_edit['select_date']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="select_time">Select Time:</label>
                        <input type="text" class="form-control" id="select_time" name="select_time" value="<?php echo $row_edit['select_time']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="quantity">Quantity:</label>
                        <input type="text" class="form-control" id="quantity" name="quantity" value="<?php echo $row_edit['quantity']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="total_price">Total Price:</label>
                        <input type="text" class="form-control" id="total_price" name="total_price" value="<?php echo $row_edit['total_price']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="paymentstatus">Payment Status:</label>
                        <input type="text" class="form-control" id="paymentstatus" name="paymentstatus" value="<?php echo $row_edit['paymentstatus']; ?>">
                    </div>
                    <!-- You can hide the order_date field if you don't want users to edit it -->
                    <div class="form-group">
                        <label for="order_date">Order Date:</label>
                        <input type="text" class="form-control" id="order_date" name="order_date" value="<?php echo $row_edit['order_date']; ?>" readonly>
                    </div>
                    <button type="submit" class="btn btn-primary" name="save">Save</button>
                </form>
            </div>
        </div>
    <?php } ?>
</div>

<!-- Bootstrap JS -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
