<?php
// Include necessary files and establish database connection
include "home.php";
$con = mysqli_connect("localhost", "root", "", "fixify");

// Fetch services from services_master table
$sql_services = "SELECT * FROM `services_master`";
$result_services = mysqli_query($con, $sql_services);

if (isset($_POST['add'])) {
       
        $username = $con->real_escape_string($_POST['username']);
        $email = $con->real_escape_string($_POST['email']);
        $phone = isset($_POST['phoneno']) ? $con->real_escape_string($_POST['phoneno']) : '';
        $address = $con->real_escape_string($_POST['address']);
        $gender = $con->real_escape_string($_POST['gender']);
        $password = $con->real_escape_string($_POST['password']);
        $services_id = isset($_POST['services']) ? $_POST['services'] : '';
$status = isset($_POST['status']) ? $con->real_escape_string($_POST['status']) : '';
        // Handle document upload if a new document is selected
        if (!empty($_FILES['doc']['name'])) {
            $doc_directory = "../partner/img/doc/";
            $doc_name = $_FILES['doc']['name'];
            $doc_temp = $_FILES['doc']['tmp_name'];
            move_uploaded_file($doc_temp, $doc_directory . $doc_name);
        }

        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        if (empty($id)) {
            $sql = "INSERT INTO `users`( `username`, `email`, `phoneno`, `address`, `gender`, `password`, `role_id`, `doc`, `services_id`, `status`, `available`, `created_at`) VALUES ('$username', '$email', '$phone', '$address', '$gender', '$hashed_password', '$doc_name', '$services_id','$status' ,NOW())";
        } else {
            $sql = "UPDATE `users` SET `username`='$username', `email`='$email', `phoneno`='$phone', 
                    `address`='$address', `gender`='$gender', `password`='$hashed_password', `doc`='$doc_name', 'status'='$status' WHERE id='$id'";
        }

        $res = mysqli_query($con, $sql);

        if ($res) {
            echo "User data saved successfully!";
        } else {
            echo "Error saving user data: " . mysqli_error($con);
        }
    }
if (isset($_POST['Updated'])) {
    $id = $_POST['id'];
    $new_username = $con->real_escape_string($_POST['new_username']);
    $new_email = $con->real_escape_string($_POST['new_email']);
    $new_phoneno = $con->real_escape_string($_POST['new_phoneno']);
    $new_address = $con->real_escape_string($_POST['new_address']);
    $new_gender = $con->real_escape_string($_POST['new_gender']);
    $new_status = isset($_POST['status']) ? $con->real_escape_string($_POST['status']) : '';

    // Handle document upload if needed

    $sql = "UPDATE `users` SET `username`='$new_username', `email`='$new_email', `phoneno`='$new_phoneno', 
            `address`='$new_address', `gender`='$new_gender', `status`='$new_status' WHERE id='$id'";

    $res = mysqli_query($con, $sql);

    if ($res) {
       
    } else {
        echo "Error updating user data: " . mysqli_error($con);
    }
}
// Fetch all users
$sql = "SELECT * FROM `users` WHERE role_id = 2"; 
$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fixify</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Custom CSS */
        .container {
            margin-left: 200px;
        }
        .scrollable-table {
            max-width: 100%;
            overflow-x: auto;
        }
    </style>
</head>
<body> 
    <h1 style="text-align: center">Manage Partner</h1>
 <br><div class="container">
      
    

    <?php if (!isset($_POST['action'])): ?>
        <?php if (!isset($_POST['edit'])) : ?>
            <?php if (isset($result) && $result->num_rows > 0): ?>
  <div class="scrollable-table">
                <table border="1" class="table table-striped">
                    <thead>
                        <tr>
                            <th>S.no</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Phone No.</th>
                            <th>Address</th>
                            <th>Gender</th> 
                            <th>status</th>
                            <th>img</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $sno = 1; ?>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td align="center"><?php echo $sno++; ?></td>
                                <td align="center"><?php echo $row["username"]; ?></td>
                                <td align="center"><?php echo $row['email']; ?></td>
                                <td align="center"><?php echo $row['phoneno']; ?></td>
                                <td align="center"><?php echo $row['address']; ?></td>
                                <td align="center"><?php echo $row['gender']; ?></td>

                              
                                        <td align="center"><?php echo $row['status'] == 0 ? 'Pending' : 'Active'; ?></td>
                                        
                                <td align="center">
    <?php if (isset($row['doc'])) : ?>
        <?php
        $imagePath = "../partner/img/doc/" . $row['doc'];
        ?>
        <img src="<?php echo $imagePath; ?>" alt="img" style="max-width: 100px; max-height: 100px;">
    <?php else : ?>
        <span>No image available</span>
    <?php endif; ?>
</td>
<td>

                                    <form method="post">
                                        <input type="hidden" name="new_username" value="<?php echo $row["username"]; ?>" required>
                                        <input type="hidden" name="new_email" value="<?php echo $row["email"]; ?>" required>
                                        <input type="hidden" name="new_phoneno" value="<?php echo $row["phoneno"]; ?>" required>
                                        <input type="hidden" name="new_address" value="<?php echo $row["address"]; ?>" required>
                                        <input type="hidden" name="new_gender" value="<?php echo $row["gender"]; ?>" required>
                                        <input type="hidden" name="new_password" value="<?php echo $row["password"]; ?>" required>
                                        <input type="submit" value="Edit" name="edit">
                                        <input type="hidden" name="id" value="<?php echo $row["id"]; ?>">
                                    </form>
                                    &nbsp;
                                    <form method="post">
                                        <input type="submit" value="Delete" name="delete">
                                        <input type="hidden" name="id" value="<?php echo $row["id"]; ?>">
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table></div>
            <?php else: ?>
                No results
            <?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>




    <?php if (isset($_POST['action'])): ?>
        <div id="editForm1">
            <form method="post" action=""><br><br>
                <table>
                    <tr>
                        <td><label for="username">Username:</label></td>
                        <td><input type="text" name="username" placeholder="Enter Username" required></td>
                    </tr>
                    <tr>
                        <td><label for="email">Email:</label></td>
                        <td><input type="email" name="email" placeholder="Enter Email" required></td>
                    </tr>
                    <tr>
                        <td><label for="phone">Phone Number:</label></td>
                        <td><input type="number" name="phoneno" placeholder="Enter Phone Number"></td>
                    </tr>
                    <tr>
                        <td><label for="address">Address:</label></td>
                        <td><textarea name="address" rows="4" cols="20" placeholder="Enter Address" required></textarea></td>
                    </tr>
                    <tr>
                        <td><label for="gender">Gender:</label></td>
                        <td>
                            <select name="gender" required>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </td>
                    </tr>
                    
                    <tr>
                        <td colspan="2"><input type="submit" name="add" value="Add"></td>
                    </tr>
                </table>
            </form>
        </div>
    <?php endif; ?>

    <?php if (isset($_POST['edit'])): ?>
        <div id="editForm2">
            <form method="post" action="">
                <table>
                    <input type="hidden" name="id" value="<?php echo $_POST['id']; ?>"><br><br>
                    <tr>
                        <td><label for="new_username">Username:</label></td>
                        <td><input type="text" id="new_username" name="new_username" value="<?php echo isset($_POST['new_username']) ? htmlspecialchars($_POST['new_username']) : ''; ?>" required></td>
                    </tr>
                    <tr>
                        <td><label for="new_email">Email:</label></td>
                        <td><input type="email" id="new_email" name="new_email" value="<?php echo isset($_POST['new_email']) ? htmlspecialchars($_POST['new_email']) : ''; ?>" required></td>
                    </tr>
                    <tr>
                        <td><label for="new_phoneno">Phone Number:</label></td>
                        <td><input type="number" id="new_phone" name="new_phoneno" value="<?php echo isset($_POST['new_phoneno']) ? htmlspecialchars($_POST['new_phoneno']) : ''; ?>" required></td>
                    </tr>
                    <tr>
                        <td><label for="new_address">Address:</label></td>
                        <td><textarea id="new_address" rows="4" cols="20" name="new_address" required><?php echo isset($_POST['new_address']) ? htmlspecialchars($_POST['new_address']) : ''; ?></textarea></td>
                    </tr>
                    <tr>
                        <td><label for="new_gender">Gender:</label></td>
                        <td>
                            <select id="new_gender" name="new_gender" required>
                                <option value="Male" <?php if (isset($_POST['new_gender']) && $_POST['new_gender'] == 'Male') echo 'selected'; ?>>Male</option>
                                <option value="Female" <?php if (isset($_POST['new_gender']) && $_POST['new_gender'] == 'Female') echo 'selected'; ?>>Female</option>
                            </select>
                        </td>
                    </tr>
                    
                    <tr>
                      <td> Status</td><td><select name="status" required>
            <option value="0" <?php if (isset($_POST['status']) && $_POST['status'] == '0') echo 'selected'; ?>>Pending</option>
            <option value="1" <?php if (isset($_POST['status']) && $_POST['status'] == '1') echo 'selected'; ?>>Active</option>
        </select></td>
                    </tr>
                    <tr>
                        <td colspan="2" align="center"><input type="submit" name="Updated" value="Update"></td>
                    </tr>
                </table>
            </form>
        </div>
    <?php endif; ?>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>


</body>
</html>
