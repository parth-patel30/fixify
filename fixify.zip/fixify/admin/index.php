<?php
include 'home.php';
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .card-body {
      text-align: center;
    }

    .card-text {
      font-size: 1.2rem;
    }

    .card-title {
      font-size: 1.5rem;
    }

    .card:hover {
      transform: scale(1.05);
      transition: transform 0.3s ease;
    }

    /* Custom card colors */
    .users-card {
      background-color: #007bff; /* Blue */
      color: #fff; /* White text */
    }

    .orders-card {
      background-color: #28a745; /* Green */
      color: #fff; /* White text */
    }

    .requests-card {
      background-color:grey; /* Red */
      color: #fff; /* White text */
    }
  </style>
</head>
<body>
  <div class="container mt-5">
    <div class="row">
      <!-- Users Card -->
      <div class="col-md-4 mb-4">
        <div class="card users-card" onclick="window.location.href='manageusers.php';" style="cursor: pointer;">
          <div class="card-body">
            <h5 class="card-title">Users</h5>
            <?php
              // Fetch total users count from the database
              $conn = mysqli_connect("localhost", "root", "", "fixify");
              if ($conn) {
                $result = mysqli_query($conn, "SELECT COUNT(id) AS total_users FROM users");
                $row = mysqli_fetch_assoc($result);
                $totalUsers = $row['total_users'];
                mysqli_close($conn);
              } else {
                $totalUsers = "N/A";
              }
            ?>
            <p class="card-text">Total users: <?php echo $totalUsers; ?></p>
          </div>
        </div>
      </div>
      
      <!-- Orders Card -->
      <div class="col-md-4 mb-4">
        <div class="card orders-card" onclick="window.location.href='manageorder.php';" style="cursor: pointer;">
          <div class="card-body">
            <h5 class="card-title">Orders</h5>
            <?php
             $conn = mysqli_connect("localhost", "root", "", "fixify");
              if ($conn) {
                $result = mysqli_query($conn, "SELECT COUNT(order_id) AS total_orders FROM orders");
                $row = mysqli_fetch_assoc($result);
                $totalOrders = $row['total_orders'];
                mysqli_close($conn);
              } else {
                $totalOrders = "N/A";
              }
            ?>
            <p class="card-text">Total orders: <?php echo $totalOrders; ?></p>
          </div>
        </div>
      </div>

      <!-- Requests Card -->
      <div class="col-md-4 mb-4">
        <div class="card requests-card" onclick="window.location.href='requests.php';" style="cursor: pointer;">
          <div class="card-body">
            <h5 class="card-title">Requests</h5>
            <?php
             $conn = mysqli_connect("localhost", "root", "", "fixify");
              if ($conn) {
                $result = mysqli_query($conn, "SELECT COUNT(request_id) AS total_requests FROM requests");
                $row = mysqli_fetch_assoc($result);
                $totalRequests = $row['total_requests'];
                mysqli_close($conn);
              } else {
                $totalRequests = "N/A";
              }
            ?>
            <p class="card-text">Total requests: <?php echo $totalRequests; ?></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
