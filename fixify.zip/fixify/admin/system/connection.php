<?php

$dir_name = "aapguj";

define("DIR_NAME", $dir_name); 

define("WEB_NAME", 'fixify'); 

if($_SERVER['HTTP_HOST']=="localhost") { 

define("URL","http://localhost/".WEB_NAME);

} else { 

define("URL","http://aaplegalcell.in");

}

if(isset($_SESSION['userid'])) { $userid = $_SESSION['userid']; } else {  $userid = 0;	}


$current_url = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

	define("current_page", $current_url);

	if($_SERVER['HTTP_HOST']=="localhost") { 

	define("DB_NAME","fixify");

	define("SERVER_NAME","localhost");

	define("USER_NAME","root");

	define("PASSWORD","");

											}  else {
											
	define("DB_NAME","fixify");

	define("SERVER_NAME","localhost");

	define("USER_NAME","root");

	define("PASSWORD","");	
											
											}
?>