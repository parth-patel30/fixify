<?php
ob_start();

@session_start();

error_reporting(1);

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include("connection.php");

############################################

#	Database Server

############################################
// For  the Database file path

include("mysqlclass.inc.php");

require("commonfunc.php");

//include("msg.inc.php");

//include("class/class_common.php");

//$obj_common = new common();

//include("class/class_paging.php");

//$obj_pager = new Pager();



?>

