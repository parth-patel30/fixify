<?php 
include 'sendsms-1.php';
function getLogin($conn,$cus_mobile,$cus_password,$gcm_no,$sim_no)
{
	$sql_sel_sta = "SELECT * FROM customer_device_tbl WHERE cus_mobile='$cus_mobile' AND cus_password='$cus_password'";
	//echo $sql_sel_sta;exit; 
	$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
	$count=mysql_num_rows($res_sel_sta);
	if($count == 1)
	{
			while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC))
			 {
			$cus_id = $row ['cus_id'];
			$cus_simno = $row ['cus_simno'];
			$cus_firstName= $row ['cus_firstName'];
			$cus_lastName = $row ['cus_lastName'];
			$rows[] = array('cus_id' => "$cus_id" ,'cus_simno' => "$cus_simno",'cus_firstName' => "$cus_firstName",'cus_lastName' => "$cus_lastName");
			}
			$sql_sel_sta1 = "SELECT * FROM gcm_tbl WHERE sim_no='$sim_no'";
			$res_sel_sta1 = mysql_query( $sql_sel_sta1, $conn );
			$count1=mysql_num_rows($res_sel_sta1);
			if($count1 == 1)
			{
				$sql_sel_up="UPDATE gcm_tbl SET gcm_no='$gcm_no' where sim_no='$sim_no'";
				//echo $sql_sel_up;exit;
				$res_sel_up =  mysql_query($sql_sel_up);
				
			}
			else 
			{
				$sql_sel_ins ="INSERT INTO gcm_tbl(cus_id,sim_no,gcm_no) VALUES ('$cus_id','$sim_no','$gcm_no')";
				$res_sel_ins = mysql_query( $sql_sel_ins, $conn );
				
			}
			
			
			
			echo json_encode($rows);
			die;		
	
	}
	
	else 
	{
		echo "0";	
	}
}
function getuserList($conn,$role_id)
{
	$sql_sel_sta = "select user_id,user_firmName FROM  user_tbl where role_id='$role_id'";
	//echo $sql_sel_sta;exit;
	$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
	if(! $res_sel_sta ) {
		die('Could not get data: ' . mysql_error());
	}
	$rows = array();
	while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC)) {
		$user_id = $row ['user_id'];
		$user_firmName = $row ['user_firmName'];
		$rows[] = array('user_id' => "$user_id" ,'user_firmName' => "$user_firmName");
	}
	
	$count=count($rows);
	
	if($count > 0)
	{
		echo json_encode($rows);
		die;
	}
	else {
		echo "null";
	}
	
	
	
}
function getRegistration($conn,$cus_firstName,$cus_lastName,$cus_mobile,$cus_password,$cus_email,$cus_city,$cus_code,$cus_simno){
	
	$serch=mysql_query("select * from customer_device_tbl where cus_mobile='$cus_mobile'");
	//echo $serch;exit;
	
	if(mysql_num_rows($serch)>0)
	{
		echo "2";
		die;
			
	}
	else {
		//$user_id1=$_SESSION['user_id'];
		if($cus_code == '')
		{
			$today=date('Y-m-d h:i:s');
			$sql_sel_sta="INSERT INTO `customer_device_tbl`(`cus_firstName`,`cus_lastName`,`cus_email`,`cus_mobile`,`cus_password`,`cus_city`,`cus_simno`,`cus_addedBy`,`cus_insertDate`) VALUES ('$cus_firstName','$cus_lastName','$cus_email','$cus_mobile','$cus_password','$cus_city','$cus_simno','1','$today')";
			$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
			$cus_id=mysql_insert_id();
			if(! $res_sel_sta ) {
				die('Not Insert Data: ' . mysql_error());
			}
			else {
				echo "1";
				die;
			}
				
		}
		else
		{
					$sql_sel_sta1 = "SELECT * FROM  user_tbl WHERE  user_code='$cus_code'";
					$res_sel_sta1 = mysql_query( $sql_sel_sta1, $conn );
					if(mysql_num_rows($res_sel_sta1)>0)
					{
						while($row = mysql_fetch_array($res_sel_sta1, MYSQL_ASSOC))
						{
							$user_id=$row['user_id'];
						}
							
						$today=date('Y-m-d h:i:s');
						
						$sql_sel_sta="INSERT INTO `customer_device_tbl`(`cus_firstName`,`cus_lastName`,`cus_email`,`cus_mobile`,`cus_password`,`cus_city`,`cus_simno`,`cus_addedBy`,`cus_insertDate`) VALUES ('$cus_firstName','$cus_lastName','$cus_email','$cus_mobile','$cus_password','$cus_city','$cus_simno','$user_id','$today')";
						$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
						$cus_id=mysql_insert_id();
						//echo $mem_id;exit;
						if(! $res_sel_sta ) {
							die('Not Insert Data: ' . mysql_error());
						}
						else {
							echo "1";
							die;
						}
							
					}
					else
					{
						
					    echo "3";
					    die;	
		            } 
		}
	
	}
	
	
}
	function getSms($conn,$cus_mobile,$random_number){
		$serch=mysql_query("select * from customer_device_tbl where cus_mobile='$cus_mobile'");
		//echo $serch;exit;
		
		if(mysql_num_rows($serch)>0)
		{
			echo "2";
			die;
				
		}
		else {
		
	
		$api_key="A7b18a684f4fa64fc02821a654cde5824";
		$msg="NexTech Approved SMS for OTP - $random_number is your NexTech Verification code. Code valid for 10 minutes only, one time use.";
		$url="http://www.nextechinfoway.in/";
		$sender="NEXTEC";
	
	
		$sendsms=new sendsms("http://alerts.spotlightsms.asia/api", $api_key, $sender);
		$sendsms->send_sms($cus_mobile, $msg, $url,'JSON');
		
		
		echo "1";
		
		
		}
		
	
	}	
	function getForgotPassword($conn,$cus_mobile){
		
		$sql_sel_sta = "SELECT * FROM customer_device_tbl WHERE  cus_mobile='$cus_mobile'";
		$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
		//$count=mysql_num_rows($res_sel_sta);
		if(mysql_num_rows($res_sel_sta)>0)
		{
		   while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC)) {
			//$cus_firstName=$row['cus_firstName'];
			//$cus_lastName=$row['cus_lastName'];
			$cus_password=$row['cus_password'];
			//$cus_email=$row['cus_email'];
		    }
		
		$api_key="A7b18a684f4fa64fc02821a654cde5824";
		$msg="NexTech Password is  - $cus_password ";
		$url="http://www.nextechinfoway.in/";
		$sender="NEXTEC";
	
	
		$sendsms=new sendsms("http://alerts.spotlightsms.asia/api", $api_key, $sender);
		$sendsms->send_sms($cus_mobile, $msg, $url,'JSON');
	
	
	
		echo "1";
	}
	else {
		echo "0";
	}
	
	
	
	}
	function getForgotPassword1($conn,$cus_mobile,$cus_password){
		
		$api_key="A7b18a684f4fa64fc02821a654cde5824";
	    $msg="NexTech Password is - $cus_password ";
		$url="http://www.nextechinfoway.in/";
		$sender="NEXTEC";
	
	
		$sendsms=new sendsms("http://alerts.spotlightsms.asia/api", $api_key, $sender);
		$sendsms->send_sms($cus_mobile, $msg, $url,'JSON');
	
	
	
		return $sendsms;
	
	
	
	
	
	}
	function getImages($conn){
		$sql_sel_sta = "select * FROM  veh_image_tbl";
		$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
	
	
		while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC)) {
			$veh_img_id = $row ['veh_img_id'];
			$veh_img_name = $row ['veh_img_name'];
			$rows[] = array('veh_img_id' => "$veh_img_id",'veh_img_name' => "$veh_img_name" );
	
				
		}
		
		$count=count($rows);
		
		if($count > 0)
		{
			echo json_encode($rows);
			die;
		}
		else {
			echo "null";
		}
	}
function getAllvehicleInfo($conn,$cus_id){
		$sql1 = "SELECT * FROM vehicle_tbl where cus_id='$cus_id'" ;
			$retval1 = mysql_query( $sql1, $conn );
			if(! $retval1 ) {
				die('Could not get data: ' . mysql_error());
			}
			$res_arr_values=array();
			//$location[]=array();
			while($row1 = mysql_fetch_array($retval1, MYSQL_ASSOC)) {
				$veh_id = $row1['veh_id'];
					$sql = "SELECT * FROM location_tbl as l ,vehicle_tbl as v,veh_image_tbl as i where l.veh_id=v.veh_id and v.veh_img_id=i.veh_img_id and l.veh_id='$veh_id' ORDER BY l.loc_id DESC LIMIT 1" ;
					$retval = mysql_query( $sql, $conn );
					if(! $retval ) {
						die('Could not get data: ' . mysql_error());
					}
					while($row = mysql_fetch_array($retval, MYSQL_ASSOC)) {
						$loc_lat = $row['loc_lat'];
						$loc_long = $row['loc_long'];
						$row['address']=getaddress($loc_lat,$loc_long);
						array_push($res_arr_values, $row);
						
						
						
						
// 						$loc_lat = $row['loc_lat'];
// 						$loc_long = $row['loc_long'];
// 						$veh_num = $row['veh_num'];
// 						$veh_model = $row['veh_model'];
// 						$veh_image = $row['veh_image'];
// 						$address=getaddress($loc_lat,$loc_long);
						
// 						//array_push($res_arr_values, $row);
// 						$res_arr_values[]= array('loc_lat' => "$loc_lat",'loc_long' => "$loc_long",'veh_num' => "$veh_num",'veh_model' => "$veh_model",'veh_image' => "$veh_image",'address' => "$address");
						
					}
											
					
			}
            $json_data = array("data"=>$res_arr_values);
            $count=count($res_arr_values);
			if($count > 0)
			{
				echo json_encode($json_data);
				die;
			}
			else {
				echo "null";
			}
	}
function insertVehicle($conn,$pro_id,$cus_id,$veh_img_id,$veh_num,$veh_model,$barcode_number){
	
				$sql_sel_sta = "SELECT * FROM  purchase_tbl WHERE  pur_barcode='$barcode_number'";
				$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
				while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC))
				{
					$pur_imei=$row['pur_imei'];
					$pur_simno=$row['pur_simno'];
	
				}
				$today=date('Y-m-d h:i:s');
				$folder1 = "img/";
				$veh_image1=$folder1.$veh_image;
				$sql_ins_med="INSERT INTO `vehicle_tbl`(`pro_id`,`cus_id`,`veh_img_id`,`veh_num`,`veh_model`,`veh_image`,`sim_no`,`imei_no`) VALUES ('$pro_id','$cus_id','$veh_img_id','$veh_num','$veh_model','$veh_image1','$pur_imei','$pur_simno')";
				$res_ins_med =mysql_query($sql_ins_med,$conn);
					
					
				$sql_up_sto="UPDATE `stock_tbl` SET  `sto_status`='5',`cus_id`='$cus_id',`user_id`='0',`sto_date`='$today' where sto_imei='$pur_imei' and sto_simno='$pur_simno'";
				$res_up_sto =mysql_query($sql_up_sto,$conn);
					
				echo "1";
				die;
			
	}
function insertDriver($conn,$cus_id,$dri_firstName,$dri_lastName,$dri_mobile){

	
			$sql_ins_med="INSERT INTO `driver_tbl`(`cus_id`,`dri_firstName`,`dri_lastName`,`dri_mobile`) VALUES ('$cus_id','$dri_firstName','$dri_lastName','$dri_mobile')";
			$res_ins_med =mysql_query($sql_ins_med,$conn);
		
	echo "1";
	die;
		
}
function getACstatus($conn,$veh_id,$ac_date)
{
	//$date = $ac_time;
   //$ac_time1 = date('Y-m-d', strtotime($date));
	//echo $ac_time1;exit;
	$sql_sel_sta = "select 	i.veh_img_name,a.ac_lat,a.ac_long,a.ac_date,a.ac_time,a.ac_status FROM ac_status_tbl as a,vehicle_tbl v,veh_image_tbl as i where a.veh_id=v.veh_id and v.veh_img_id=i.veh_img_id and a.veh_id='$veh_id' and a.ac_date='$ac_date'";
	//echo $sql_sel_sta;exit;
	$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
	if(! $res_sel_sta ) {
		die('Could not get data: ' . mysql_error());
	}
	$rows = array();
	while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC)) {
		
		$veh_image = $row ['veh_img_name'];
		$ac_lat = $row ['ac_lat'];
		$ac_long = $row ['ac_long'];
		$ac_time = $row ['ac_time'];
		$ac_status = $row ['ac_status'];
		$ac_date = $row ['ac_date'];
		$address=getaddress_ac($ac_lat,$ac_long);
		$rows[] = array('veh_image' => "$veh_image",'ac_lat' => "$ac_lat",'ac_long' => "$ac_long",'ac_time' => "$ac_time",'ac_date' => "$ac_date",'ac_status' => "$ac_status",'address' => "$address");
	
	}
	$count=count($rows);
	if($count > 0)
	{
		echo json_encode($rows);
		echo notification($conn);
		die;
	}
	else {
		echo "null";
	}
	
}
function  getIGNstatus($conn,$veh_id,$ign_date)
{
	//$date = $ac_time;
	//$ac_time1 = date('Y-m-d', strtotime($date));
	//echo $ac_time1;exit;
	$sql_sel_sta = "select 	vi.veh_img_name,i.ign_lat,i.ign_long,i.ign_time,i.ign_date,i.ign_status FROM ignition_status_tbl as i,vehicle_tbl as v,veh_image_tbl as vi where i.veh_id=v.veh_id and  v.veh_img_id=vi.veh_img_id and i.veh_id='$veh_id' and i.ign_date='$ign_date'";
	//echo $sql_sel_sta;exit;
	$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
	if(! $res_sel_sta ) {
		die('Could not get data: ' . mysql_error());
	}
	$rows = array();
	while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC)) {

		$veh_image = $row ['veh_img_name'];
		$ign_lat = $row ['ign_lat'];
		$ign_long = $row ['ign_long'];
		$ign_time = $row ['ign_time'];
		$ign_status = $row ['ign_status'];
		$address=getaddress_ign($ign_lat,$ign_long);
		$rows[] = array('veh_image' => "$veh_image",'ign_lat' => "$ign_lat",'ign_long' => "$ign_long",'ign_time' => "$ign_time",'ign_date' => "$ign_date",'ign_status' => "$ign_status",'address' => "$address" );

	}
    $count=count($rows);
	if($count > 0)
	{
		echo json_encode($rows);
		die;
	}
	else {
		echo "null";
	}
}
function  getCitystatus($conn,$veh_id,$city_date)
{
	//$date = $ac_time;
	//$ac_time1 = date('Y-m-d', strtotime($date));
	//echo $ac_time1;exit;
	$sql_sel_sta = "select 	vi.veh_img_name,c.city_lat,c.city_long,c.city_time,c.city_date,c.city_status FROM city_status_tbl as c,vehicle_tbl v,veh_image_tbl as vi where c.veh_id=v.veh_id and v.veh_img_id=vi.veh_img_id and c.veh_id='$veh_id' and c.city_date='$city_date'";
	//echo $sql_sel_sta;exit;
	$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
	if(! $res_sel_sta ) {
		die('Could not get data: ' . mysql_error());
	}
	$rows = array();
	while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC)) {

		$veh_image = $row['veh_img_name'];
		$city_lat = $row ['city_lat'];
		$city_long = $row['city_long'];
		$city_time = $row['city_time'];
		$city_date = $row['city_date'];
		$city_status = $row['city_status'];
		$address=getaddress_city($city_lat,$city_long);
		$rows[] = array('veh_image' => "$veh_image",'city_lat' => "$city_lat",'city_long' => "$city_long",'city_time' => "$city_time",'city_date' => "$city_date",'city_status' => "$city_status",'address' => "$address");

	}
    $count=count($rows);
	if($count > 0)
	{
		echo json_encode($rows);
		die;
	}
	else {
		echo "null";
	}
}
function getCustomerList($conn,$cus_id)
{
	$sql_sel_sta = "select cus_firstName,cus_lastName,cus_mobile,cus_email  FROM  customer_device_tbl where cus_id='$cus_id'";
	//echo $sql_sel_sta;exit;
	$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
	if(! $res_sel_sta ) {
		die('Could not get data: ' . mysql_error());
	}
	$rows = array();
	while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC)) {
		$cus_firstName = $row ['cus_firstName'];
		$cus_lastName = $row ['cus_lastName'];
		$cus_mobile = $row ['cus_mobile'];
		$cus_email = $row ['cus_email'];
		$rows[] = array('cus_firstName' => "$cus_firstName" ,'cus_lastName' => "$cus_lastName",'cus_mobile' => "$cus_mobile",'cus_email' => "$cus_email");
	}
    $count=count($rows);
	if($count > 0)
	{
		echo json_encode($rows);
		die;
	}
	else {
		echo "null";
	}
}
function editProfile($conn,$cus_id,$cus_firstName,$cus_lastName,$cus_mobile,$cus_email){
	$sql_sel_sta="UPDATE customer_device_tbl SET cus_firstName='$cus_firstName',cus_lastName='$cus_lastName',cus_mobile='$cus_mobile',cus_email='$cus_email' where cus_id='$cus_id'";
	$res_sel_sta =  mysql_query($sql_sel_sta);
	if(! $res_sel_sta ) {
		echo "0";
		die;
	}

	else {
		echo "1";
		die;
	}

}
function changePassword($conn,$cus_id,$cus_password){

	$sql_sel_sta="UPDATE customer_device_tbl SET cus_password='$cus_password' where cus_id='$cus_id'";
	//$sql_sel_sta="UPDATE member_tbl SET mem_firstName='$mem_firstName',mem_lastName='$mem_lastName',mem_mobile='$mem_mobile',mem_email='$mem_email' where mem_id='$mem_id'";
	$res_sel_sta =  mysql_query($sql_sel_sta);
	if(! $res_sel_sta ) {
		echo "0";
		die;
	}

	else {
		echo "1";
		die;
	}



}
function getCurrentLocation($conn,$veh_id)
{
	$sql = "SELECT * FROM location_tbl as l ,vehicle_tbl as v,customer_device_tbl as c,veh_image_tbl as i where l.veh_id=v.veh_id and v.cus_id=c.cus_id and v.veh_img_id=i.veh_img_id and l.veh_id='$veh_id'  ORDER BY l.loc_id DESC LIMIT 1" ;
	$retval = mysql_query( $sql, $conn );
	if(! $retval ) {
		die('Could not get data: ' . mysql_error());
	}
	$data = array();
	while($row = mysql_fetch_array($retval, MYSQL_ASSOC)) {
	
		$cus_firstName = $row ['cus_firstName'];
		$loc_lat = $row ['loc_lat'];
		$loc_long = $row ['loc_long'];
		$veh_num = $row ['veh_num'];
		$veh_image = $row ['veh_img_name'];
		$veh_model = $row ['veh_model'];
		$address=getaddress($loc_lat,$loc_long);
		//echo $address;exit;
		$data[]= array('cus_firstName' => "$cus_firstName" ,'loc_lat' => "$loc_lat",'loc_long' => "$loc_long",'veh_num' => "$veh_num",'veh_model' => "$veh_model",'veh_image' => "$veh_image",'address' => "$address");
			
	}
	$json_data = array("data"=>$data);
	$count=count($data);
	
	if($count > 0)
	{
		echo json_encode($json_data);
		die;
	}
	else {
		echo "null";
	}
	
		
}
function  getSpeed($conn,$veh_id,$loc_time,$loc_speed)
{
	//$date = $ac_time;
	//$ac_time1 = date('Y-m-d', strtotime($loc_time));
	//echo $ac_time1;exit;
	$sql_sel_sta = "select 	l.loc_lat,l.loc_long,l.loc_speed,l.loc_time,i.veh_img_name FROM location_tbl as l,vehicle_tbl as v,veh_image_tbl as i  where l.veh_id=v.veh_id and v.veh_img_id=i.veh_img_id and l.veh_id='$veh_id' and DATE_FORMAT(l.loc_time, '%Y-%m-%d')='$loc_time' and l.loc_speed >= '$loc_speed'";
	//echo $sql_sel_sta;exit;
	$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
	if(! $res_sel_sta ) {
		die('Could not get data: ' . mysql_error());
	}
	$rows = array();
	while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC)) {
		$loc_time = $row ['loc_time'];
		$loc_lat = $row ['loc_lat'];
		$loc_long = $row ['loc_long'];
		$loc_speed = $row ['loc_speed'];
		$veh_image = $row ['veh_img_name'];
		$address=getaddress($loc_lat,$loc_long);
		$rows[] = array('loc_lat' => "$loc_lat",'loc_long' => "$loc_long",'loc_speed' => "$loc_speed",'loc_time' => "$loc_time",'address' => "$address",'veh_image' => "$veh_image");

	}
	
	$count=count($rows);
	
	if($count > 0)
	{
		echo json_encode($rows);
		die;
	}
	else {
		echo "null";
	}
}
function getLocation($conn,$loc_lat,$loc_long){
	$today=date('Y-m-d h:i:s');
	$sql_sel_sta ="INSERT INTO `location_tbl`(`veh_id` ,`loc_lat`,`loc_long`,`loc_time`,`loc_speed`,`loc_ac_status`,`loc_ig_status`,`loc_acc_status`) VALUES ('1','$loc_lat','$loc_long','$today','34','1','1','1')";
	//echo $sql_sel_sta;exit;
	$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
		
	if(! $res_sel_sta ) {
		die('Not Insert Data: ' . mysql_error());
	}
	else {
		echo "1";die;
	}
}
function getDriver($conn,$cus_id)
{
	$sql_sel_sta = "select 	* FROM driver_tbl where cus_id='$cus_id'";
	$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
	if(! $res_sel_sta ) {
		die('Could not get data: ' . mysql_error());
	}
	$rows = array();
	while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC)) {
		$dri_id = $row['dri_id'];
		$dri_firstName = $row['dri_firstName'];
		$dri_lastName = $row ['dri_lastName'];
		$dri_mobile = $row ['dri_mobile'];
		$rows[] = array('dri_id' => "$dri_id",'dri_firstName' => "$dri_firstName",'dri_lastName' => "$dri_lastName",'dri_mobile' => "$dri_mobile");

	}
	$count=count($rows);
	if($count > 0)
	{
		echo json_encode($rows);
		die;
	}
	else {
		echo "null";
	}

}
function getTodayData($conn,$veh_id)
{
	$date=date('Y-m-d');
	$sql_sel_sta = "select 	* FROM location_tbl as l,vehicle_tbl as v,veh_image_tbl as i where l.veh_id=v.veh_id and v.veh_img_id=i.veh_img_id and DATE_FORMAT(l.loc_time, '%Y-%m-%d')='$date' and l.veh_id='$veh_id'";
	$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
	if(! $res_sel_sta ) {
		die('Could not get data: ' . mysql_error());
	}
	$rows = array();
	while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC)) {

		$loc_lat = $row['loc_lat'];
		$loc_long = $row ['loc_long'];
		$veh_image = $row ['veh_img_name'];
		$loc_time = $row ['loc_time'];
		$loc_speed = $row ['loc_speed'];
		$address=getaddress($loc_lat,$loc_long);
		$rows[] = array('loc_lat' => "$loc_lat",'loc_long' => "$loc_long",'veh_image' => "$veh_image",'loc_time' => "$loc_time",'loc_speed' => "$loc_speed",'address' => "$address");

	}
	$count=count($rows);
	if($count > 0)
	{
		echo json_encode($rows);
		die;
	}
	else {
		echo "null";
	}

}

function getVehicle($conn,$cus_id,$pro_id,$veh_model,$veh_num,$veh_img_id,$barcode_number){
	        $today=date('Y-m-d h:i:s');
		    $sql_sel_sta = "SELECT * FROM  purchase_tbl WHERE  pur_barcode='$barcode_number'";
			$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
			if(mysql_num_rows($res_sel_sta)>0)
			{
				$rows = array();
			while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC))
			{
				$pur_imei=$row['pur_imei'];
				$pur_simno=$row['pur_simno'];
				$rows[] = array('pur_imei' => "$pur_imei",'pur_simno' => "$pur_simno");
				
			}
			//$folder1 = "img/";
			//$veh_image1=$folder1.$veh_image;
			$sql_ins_med="INSERT INTO `vehicle_tbl`(`cus_id`,`pro_id`,`veh_img_id`,`veh_num`,`veh_model`,`sim_no`,`imei_no`) VALUES ('$cus_id','$pro_id','$veh_img_id','$veh_num','$veh_model','$veh_image1','$pur_imei','$pur_simno')";
			$res_ins_med =mysql_query($sql_ins_med,$conn);
				
				
			$sql_up_sto="UPDATE `stock_tbl` SET  `sto_status`='5',`cus_id`='$cus_id',`user_id`='0',`sto_date`='$today' where sto_imei='$pur_imei' and sto_simno='$pur_simno'";
			$res_up_sto =mysql_query($sql_up_sto,$conn);
				
			
				echo json_encode($rows);
				die;
			
			}
			else {
				echo "0";
				die;
			}
		
}
function getVehicleStatus($conn,$cus_id)
{
	        $sql1 = "SELECT * FROM vehicle_tbl as v,customer_device_tbl as c where v.cus_id=c.cus_id and v.cus_id='$cus_id'" ;
			$retval1 = mysql_query( $sql1, $conn );
			//$count1=mysql_num_rows($retval1);
			        $rows = array();
					$car_on='';
					$car_off='';
					$car_stop='';
					$car_acc='';
					while($row1 = mysql_fetch_array($retval1, MYSQL_ASSOC))
				    {
						$veh_id = $row1['veh_id'];
						$sql = "SELECT DISTINCT veh_id FROM location_tbl  where veh_id='$veh_id' and loc_speed > '0' and loc_ig_status ='1' ORDER BY loc_id DESC LIMIT 1" ;
						$retval = mysql_query( $sql, $conn );
						$car_on += mysql_num_rows($retval);
						
						
						$sql_off = "SELECT * FROM location_tbl  where veh_id='$veh_id' and loc_speed = '0' and loc_ig_status ='0' ORDER BY loc_id DESC LIMIT 1" ;
						$retval_off = mysql_query( $sql_off, $conn );
						$car_off += mysql_num_rows($retval_off);
						
						$sql_stop = "SELECT * FROM location_tbl  where veh_id='$veh_id' and loc_speed = '0' and loc_ig_status ='1' ORDER BY loc_id DESC LIMIT 1" ;
						$retval_stop = mysql_query( $sql_stop, $conn );
						$car_stop += mysql_num_rows($retval_stop);
						
						$sql_acc = "SELECT * FROM location_tbl  where veh_id='$veh_id' and loc_acc_status ='1' ORDER BY loc_id DESC LIMIT 1" ;
						$retval_acc = mysql_query( $sql_acc, $conn );
						$car_acc += mysql_num_rows($retval_acc);
						
						
				    }
				    $rows[] = array('On' => "$car_on",'Off' => "$car_off",'Stop' => "$car_stop",'Acc' => "$car_acc");
					echo json_encode($rows);
				    die;
				    				
				    
}
function vehicleInfo($conn,$cus_id){
    //$date=date('Y-m-d');
	$sql_sel_sta = "select 	* FROM vehicle_tbl as v,veh_image_tbl as i where v.veh_img_id=i.veh_img_id and cus_id='$cus_id'";
	$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
	if(! $res_sel_sta ) {
		die('Could not get data: ' . mysql_error());
	}
	$rows = array();
	while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC)) {

		$veh_id = $row['veh_id'];
		$veh_model = $row ['veh_model'];
		$veh_num = $row ['veh_num'];
		$veh_image = $row ['veh_img_name'];
		$rows[] = array('veh_id' => "$veh_id",'veh_model' => "$veh_model",'veh_num' => "$veh_num",'veh_image' => "$veh_image");

	}
	$count=count($rows);
	if($count > 0)
	{
		echo json_encode($rows);
		die;
	}
	else {
		echo "null";
	}
}
function getAssignVehicle($conn,$cus_id,$veh_id,$dri_id){
		$serch=mysql_query("select * from assign_vehicle_driver_tbl where dri_id='$dri_id'");
		
		if(mysql_num_rows($serch)>0)
		{
			echo "2";
			die;
		}
		else {
				$sql_ins_med="INSERT INTO `assign_vehicle_driver_tbl`(`veh_id`,`dri_id`,`cus_id`) VALUES ('$veh_id','$dri_id','$cus_id')";
				//echo $sql_ins_med;exit;
				$res_ins_med =mysql_query($sql_ins_med,$conn);
				if(!$res_ins_med)
				{
						echo "0";
						die;
				}
				else
				{
						echo "1";
						die;
				}
										
		
				
		
	 } 

}
function editDriver($conn,$dri_id,$dri_firstName,$dri_lastName,$dri_mobile)
{
	        $sql_up_med="UPDATE `driver_tbl` SET `dri_firstName`='$dri_firstName',`dri_lastName`='$dri_lastName',`dri_mobile`='$dri_mobile'  where dri_id='$dri_id'";
			$res_up_med =  mysql_query($sql_up_med);
			if(!$res_up_med){
				echo "0";
				die;
			}else{
				echo "1";
				die;
			}
}
function getOneDriverInfo($conn,$dri_id)
{
	$sql_sel_sta = "select 	* FROM driver_tbl where dri_id='$dri_id'";
	$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
	if(! $res_sel_sta ) {
		die('Could not get data: ' . mysql_error());
	}
	$rows = array();
	while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC)) {
		//$dri_id = $row['dri_id'];
		$dri_firstName = $row['dri_firstName'];
		$dri_lastName = $row ['dri_lastName'];
		$dri_mobile = $row ['dri_mobile'];
		$rows[] = array('dri_firstName' => "$dri_firstName",'dri_lastName' => "$dri_lastName",'dri_mobile' => "$dri_mobile");

	}
	$count=count($rows);
	if($count > 0)
	{
		echo json_encode($rows);
		die;
	}
	else {
		echo "null";
	}

}
function getTempData($conn,$loc_id)
{
	
	$sql_sel_sta = "SELECT * FROM location_tbl where loc_id='$loc_id'";
	$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
	if(! $res_sel_sta ) {
		die('Could not get data: ' . mysql_error());
	}
	$rows = array();
	while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC)) {
		//$dri_id = $row['dri_id'];
		$loc_lat = $row['loc_lat'];
		$loc_long = $row ['loc_long'];
		$loc_id = $row ['loc_id'];
		$loc_id_num=$loc_id + 1;
		$rows[] = array('loc_lat' => "$loc_lat",'loc_long' => "$loc_long",'loc_id' => "$loc_id_num");

	}
	$count=count($rows);
	if($count > 0)
	{
		echo json_encode($rows);
		die;
	}
	else {
		echo "null";
	}

}
function getAssignOneVehicle($conn,$veh_id)
{
	$sql_sel_sta = "select 	* FROM assign_vehicle_driver_tbl as a,driver_tbl as d where a.dri_id=d.dri_id and a.veh_id='$veh_id'";
	$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
	if(! $res_sel_sta ) {
		die('Could not get data: ' . mysql_error());
	}
	$rows = array();
	while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC)) {
		$dri_id = $row['dri_id'];
		$dri_firstName = $row['dri_firstName'];
		$dri_lastName = $row ['dri_lastName'];
		$dri_mobile = $row ['dri_mobile'];
		$rows[] = array('dri_id' => "$dri_id",'dri_firstName' => "$dri_firstName",'dri_lastName' => "$dri_lastName",'dri_mobile' => "$dri_mobile");

	}
	$count=count($rows);
	if($count > 0)
	{
		echo json_encode($rows);
		die;
	}
	else {
		echo "null";
	}

}
function getOneVehicleInfo($conn,$veh_id,$cus_id)
{
	
	$sql_sel_sta = "select 	* FROM customer_device_tbl where cus_id='$cus_id'";
	$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
	
	$rows = array();
	while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC)) {
		$cus_insertDate = $row['cus_insertDate'];
					$sql = "SELECT * FROM location_tbl as l ,vehicle_tbl as v,veh_image_tbl as i  where l.veh_id=v.veh_id and  v.veh_img_id=i.veh_img_id and l.veh_id='$veh_id' ORDER BY l.loc_id DESC LIMIT 1" ;
					$retval = mysql_query( $sql, $conn );
					
					while($row = mysql_fetch_array($retval, MYSQL_ASSOC)) {
						$veh_img_id = $row['veh_img_id'];
						$veh_img_name = $row['veh_img_name'];
						$veh_model = $row ['veh_model'];
						$veh_num = $row ['veh_num'];
						$loc_lat = $row['loc_lat'];
						$loc_long = $row['loc_long'];
						$loc_time = $row['loc_time'];
						$loc_speed = $row['loc_speed'];
						$loc_ac_status = $row['loc_ac_status'];
						$loc_ig_status = $row['loc_ig_status'];
						$veh_id = $row['veh_id'];
						$thisYear =date('Y', strtotime($cus_insertDate));
						$expiryYear=$thisYear + 1;
						$expiry_date = date(''.$expiryYear.'-m-d h:i:s', strtotime($cus_insertDate));
						//$expiry_date=date('(Y + 5)-m-d');
						$rows[] = array('veh_id' => "$veh_id",'veh_img_id' => "$veh_img_id",'veh_img_name' => "$veh_img_name",'veh_model' => "$veh_model",'veh_num' => "$veh_num",'loc_lat' => "$loc_lat",'loc_long' => "$loc_long",'loc_time' => "$loc_time",'loc_speed' => "$loc_speed",'loc_ac_status' => "$loc_ac_status",'loc_ig_status' => "$loc_ig_status",'cus_insertDate' => "$cus_insertDate",'expiry_date' => "$expiry_date");
						
					
					}
					
	}
	$count=count($rows);
	if($count > 0)
	{
		echo json_encode($rows);
		die;
	}
	else {
		echo "null";
	}

}
function editVehicleInfo($conn,$veh_id,$veh_img_id,$veh_model,$veh_num)
{
	$sql_up_med="UPDATE `vehicle_tbl` SET `veh_img_id`='$veh_img_id',`veh_model`='$veh_model',`veh_num`='$veh_num'  where veh_id='$veh_id'";
	$res_up_med =  mysql_query($sql_up_med);
	if(!$res_up_med){
		echo "0";
		die;
	}else{
		echo "1";
		die;
	}
}
function getYesterdayData($conn,$veh_id)
{
	
	$date=date('Y-m-d');
	$thisDay =date('d', strtotime($date));
	
	$yesterday=$thisDay - 1;
	$yesterday_date = date('Y-m-'.$yesterday.'', strtotime($date));
	
	$sql_sel_sta = "select 	* FROM location_tbl as l,vehicle_tbl as v,veh_image_tbl as i where l.veh_id=v.veh_id and v.veh_img_id=i.veh_img_id and DATE_FORMAT(l.loc_time, '%Y-%m-%d')='$yesterday_date' and l.veh_id='$veh_id'";
	
	$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
	if(! $res_sel_sta ) {
		die('Could not get data: ' . mysql_error());
	}
	$rows = array();
	while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC)) {

		$loc_lat = $row['loc_lat'];
		$loc_long = $row ['loc_long'];
		$veh_image = $row ['veh_img_name'];
		$loc_time = $row ['loc_time'];
		$loc_speed = $row ['loc_speed'];
		$address=getaddress($loc_lat,$loc_long);
		$rows[] = array('loc_lat' => "$loc_lat",'loc_long' => "$loc_long",'veh_image' => "$veh_image",'loc_time' => "$loc_time",'loc_speed' => "$loc_speed",'address' => "$address");

	}
	$count=count($rows);
	if($count > 0)
	{
		echo json_encode($rows);
		die;
	}
	else {
		echo "null";
	}

}
function getDateWiseData($conn,$veh_id,$startDate,$endDate)
{
	$sql_sel_sta = "select 	* FROM location_tbl as l,vehicle_tbl as v,veh_image_tbl as i where l.veh_id=v.veh_id and v.veh_img_id=i.veh_img_id and l.veh_id='$veh_id' and  DATE_FORMAT(l.loc_time, '%Y-%m-%d') BETWEEN '$startDate' AND '$endDate'";

	$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
	if(! $res_sel_sta ) {
		die('Could not get data: ' . mysql_error());
	}
	$rows = array();
	while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC)) {

		$loc_lat = $row['loc_lat'];
		$loc_long = $row ['loc_long'];
		$veh_image = $row ['veh_img_name'];
		$loc_time = $row ['loc_time'];
		$loc_speed = $row ['loc_speed'];
		$address=getaddress($loc_lat,$loc_long);
		$rows[] = array('loc_lat' => "$loc_lat",'loc_long' => "$loc_long",'veh_image' => "$veh_image",'loc_time' => "$loc_time",'loc_speed' => "$loc_speed",'address' => "$address");

	}
	$count=count($rows);
	if($count > 0)
	{
		echo json_encode($rows);
		die;
	}
	else {
		echo "null";
	}

}
function getOneHourData($conn,$veh_id)
{
	$date=date('Y-m-d h:i:s');
	$thisHour =date('h', strtotime($date));
	$lastData=$thisHour - 1;
	$show_date = date('Y-m-d 0'.$lastData.'', strtotime($date));
	
	$sql_sel_sta = "select 	* FROM location_tbl as l,vehicle_tbl as v,veh_image_tbl as i where l.veh_id=v.veh_id and v.veh_img_id=i.veh_img_id and DATE_FORMAT(l.loc_time, '%Y-%m-%d %h')='$show_date' and l.veh_id='$veh_id'";
	//echo $sql_sel_sta;exit;
	$res_sel_sta = mysql_query( $sql_sel_sta, $conn );
	if(! $res_sel_sta ) {
		die('Could not get data: ' . mysql_error());
	}
	$rows = array();
	while($row = mysql_fetch_array($res_sel_sta, MYSQL_ASSOC)) {

		$loc_lat = $row['loc_lat'];
		$loc_long = $row ['loc_long'];
		$veh_image = $row ['veh_img_name'];
		$loc_time = $row ['loc_time'];
		$loc_speed = $row ['loc_speed'];
		$address=getaddress($loc_lat,$loc_long);
		$rows[] = array('loc_lat' => "$loc_lat",'loc_long' => "$loc_long",'veh_image' => "$veh_image",'loc_time' => "$loc_time",'loc_speed' => "$loc_speed",'address' => "$address");

	}
	$count=count($rows);
	if($count > 0)
	{
		echo json_encode($rows);
		die;
	}
	else {
		echo "null";
	}

}
function getNotification($conn)
{
	error_reporting(-1);
	ini_set('display_errors', 'On');
	include '../firebase.php';
	include '../push.php';
	$firebase = new Firebase();
	$push = new Push();

	// optional payload
	$payload = array();
	$payload['team'] = 'India';
	$payload['score'] = '5.6';

	// notification title
	$title = 'hello';

	// notification message
	$message = 'this is notification';
	$push_type = 'topic';
	$push->setTitle($title);
	$push->setMessage($message);
	$push->setIsBackground(FALSE);
	$push->setPayload($payload);
	$json = '';
	$response = '';

	$sql_sel_sub="select * FROM  gcm_tbl";
	$res_sel_sub= mysql_query($sql_sel_sub,$conn);

	while ($row=mysql_fetch_array($res_sel_sub ))
	{
			
		$gcm_no =$row['gcm_no'];
		//echo $gcm_no;exit;
		$json = $push->getPush();
		$response = $firebase->send($gcm_no, $json);
	}

	
}
?>