<?php

  

	class dbclass {	

		var $CONN;
		
		public function __construct() { //constructor

			$conn = mysqli_connect(SERVER_NAME,USER_NAME,PASSWORD,DB_NAME);	

			if(!$conn) 

				{	$this->error("Connection attempt failed", $conn);		}

	if(!mysqli_select_db($conn, DB_NAME)) 

				{	$this->error("Database Selection failed", $conn);		}

			$this->CONN = $conn;

			return true;

		}
		
		public function dbclass()
    	{
        self::__construct();
   		 }

		//_____________close connection____________//

		function close(){



			$conn = $this->CONN ;

			$close = mysqli_close($conn);

			if(!$close){

			  $this->error("Close Connection Failed", $conn);	}

			return true;

		}

		function error($text, $conn) {

			$no = mysqli_errno($conn);

			$msg = mysqli_error($conn);

			echo "<hr><font face=verdana size=2>";

			echo "<b>Custom Message :</b> $text<br><br>";

			echo "<b>Error Number :</b> $no<br><br>";

			echo "<b>Error Message	:</b> $msg<br><br>";

			echo "<hr></font>";

			exit;

		}

		//_____________select records___________________//

		function select ($sql=""){

			if(empty($sql)) { return false; }

					preg_match("/(SELECT)/", $sql, $matches, PREG_OFFSET_CAPTURE);
			
			if(count($matches)==0) {	 return false;		}

				if(empty($this->CONN)){	return false;		}

			$conn = $this->CONN;			


			$results = @mysqli_query($conn, $sql);		

			if((!$results) or empty($results))	{	return false;		}

			$count = 0;

			$data  = array();

			while ( $row = mysqli_fetch_array($results))	

			

			{	

				$data[$count] = $row;

				$count++;		

				

			}

			mysqli_free_result($results);
			
			//print_r($data);//die;

			return $data;

		}
		
		

	 

	    //________insert record__________________//

		function insert ($sql=""){

			if(empty($sql)) { return false; }

			preg_match("/(INSERT)/", $sql, $matches, PREG_OFFSET_CAPTURE);
			
			if(count($matches)==0) {	 return false;		}
			//echo $sql;die('2');

			if(empty($this->CONN)){	return false;		}

			$conn = $this->CONN;			

			$results = @mysqli_query($conn,$sql);			

			if(!$results){

			$this->error("Insert Operation Failed..<hr>$sql<hr>", $conn);

			return false;		}

			$id = mysqli_insert_id($conn);

			return $id;

		}

	    //___________edit and modify record___________________//

		function edit($sql="")	{

			if(empty($sql)) { 	return false; 		}

			/*preg_match("/(UPDATE)/", $sql, $matches, PREG_OFFSET_CAPTURE);
			
			if(count($matches)==0) {	 return false;		}*/

			if(empty($this->CONN)){	return false;		}

			$conn = $this->CONN;

			$results = mysqli_query($conn,$sql);

			$rows = 0;

			$rows = mysqli_affected_rows($conn);

			return $rows;

		}

		//____________generalize for all queries___________//

		function sql_query($sql="")	{	

			

			if(empty($sql)) { return false; }

			if(empty($this->CONN)) { return false; }

			$conn = $this->CONN;

			$results = mysqli_query($conn,$sql) or $this->error("Something wrong in query<hr>$sql<hr>", $conn);

			

			if(!$results){

			   $this->error("Query went bad ! <hr>$sql<hr>", $conn);

					return false;		}		

			preg_match("/(SELECT)/", $sql, $matches, PREG_OFFSET_CAPTURE);
			
			if(count($matches)==0) {	 return false;		}

			else {

		  	    $count = 0;

				$data = array();

				while ( $row = mysqli_fetch_array($results))

				{	$data[$count] = $row;

					$count++;				}

				mysqli_free_result($results);

				return $data;

		 	}

		}	

		

	function extraqueries($sql="")	{	

			if(empty($sql)) { return false; }

			if(empty($this->CONN)) { return false; }

			$conn = $this->CONN;

			$results = mysqli_query($conn, $sql) or $this->error("Something wrong in query<hr>$sql<hr>", $conn);

			

			if(!$results){

			   $this->error("Query went bad ! <hr>$sql<hr>", $conn);

					return false;		}		

			else {

		  	    $count = 0;

				$data = array();

				while ( $row = mysqli_fetch_array($results))

				{	$data[$count] = $row;

					$count++;				}

				mysqli_free_result($results);

				return $data;

		 	}

		}	

	

	} 



?>