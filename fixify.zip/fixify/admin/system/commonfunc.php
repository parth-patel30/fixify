<?php

	


		function curPageURL() 

		{

		

		 $pageURL = 'http';

		

		 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}

		

		 $pageURL .= "://";

		

		 if ($_SERVER["SERVER_PORT"] != "80") {

		

		  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];

		

		 } 

		 

		 else 

		 

		 {

		 

		  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];

		 

		 }

		 

		 return $pageURL;

		

		}


		function send_mail($to, $subject, $message, $from)

	{

	

			 $headers  = 'MIME-Version: 1.0' . "\r\n";

		 	 $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

		 	 $headers .="from: ".$from;

	

			 mail($to, $subject, $message, $headers);

			

			 return true;

	}
	
	

	

		
		

?>



