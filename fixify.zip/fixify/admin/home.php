<?php
session_start();


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fixify";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if (isset($_SESSION['user_id'])) {
  $user_id = $_SESSION['user_id'];

} else {
 header("Location: ../index.php");
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Fixify</title>
  <link rel="icon" type="image/x-icon" href="fixify12.png">
    <style type="text/css">
    .sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #343a40;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
    margin-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}
.custom-icon path {
    fill: white; 
}
.slidenav{
	font-size:30px;
	cursor:pointer;
	margin-left: 1%;
}
.slidenav:hover{
	
	border-radius: 10px;
	background-color: 	#EAEBEC;
}

    </style>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- Custom CSS -->
</head>
<body>
    
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <a class="navbar-brand" href="index.php"><div style="font-size: 30px;text-shadow: 2px 2px 4px white;">Fixify</div></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                
               
                   
&nbsp;&nbsp;&nbsp;&nbsp;
               
            </ul>
        </div>
    </nav>
<div id="mySidenav" class="sidenav">

        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <a href="index.php">Home </a>
        <a href="manageusers.php">Manage Users</a>
        <a href="managepartner.php">Manage Partner</a>

        <a href="manageservices.php">Manage Services</a>
        <a href="manageorder.php">Manage Orders</a>
        <a href="requests.php">Manage Requests</a>

        <a href="managecontact.php">Manage Contact</a>
        <!-- More items here -->
        <a href="../index.php">Logout</a>
    </div>

    <!-- Use any element to open the sidenav -->
    <span class="slidenav" onclick="openNav()">&#9776;</span>

    <!-- Home Page Content -->
    <div class="container">
     
        <!-- More content here -->
    </div>

    <!-- jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript">
    	function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
    </script>
</body>
</html>
