<?php
include "home.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Requests</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2>Manage Requests</h2>
    <?php
    // Include database connection
    include_once 'db_connect.php';

    // Function to escape HTML and prevent SQL injection
    function cleanInput($input)
    {
        $cleaned = htmlspecialchars(strip_tags($input));
        return $cleaned;
    }

    // Handle delete action
    if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
        $request_id = cleanInput($_GET['id']);
        $sql_delete = "DELETE FROM requests WHERE request_id = $request_id";
        mysqli_query($conn, $sql_delete);
        echo '<div class="alert alert-success">Request deleted successfully!</div>';
    }

    // Handle form submission for creating or updating a request
    if (isset($_POST['save'])) {
        $request_id = cleanInput($_POST['request_id']);
        $userid = cleanInput($_POST['userid']);
        $roleid = cleanInput($_POST['roleid']);
        $title = cleanInput($_POST['title']);
        $description = cleanInput($_POST['description']);
        $status = cleanInput($_POST['status']);

        if ($request_id == '') {
            // Create new request
            $sql_insert = "INSERT INTO requests (userid, roleid, title, description, status, created_at, updated_at) 
                           VALUES ($userid, $roleid, '$title', '$description', $status, current_timestamp(), current_timestamp())";
            mysqli_query($conn, $sql_insert);
            echo '<div class="alert alert-success">Request created successfully!</div>';
        } else {
            // Update existing request
            $sql_update = "UPDATE requests SET userid = $userid, roleid = $roleid, title = '$title', 
                           description = '$description', status = $status, updated_at = current_timestamp() 
                           WHERE request_id = $request_id";
            mysqli_query($conn, $sql_update);
            echo '<div class="alert alert-success">Request updated successfully!</div>';
        }
    }

    // Fetch requests from the database with username and roles from role_master
    $sql_select = "SELECT r.*, u.username, rm.roles
                   FROM requests r 
                   JOIN users u ON r.userid = u.id
                   JOIN role_master rm ON r.roleid = rm.role_id";
    $result = mysqli_query($conn, $sql_select);
    ?>
    <table class="table">
        <thead>
            <tr>
                <th>Request ID</th>
                <th>Username</th>
                <th>Role</th>
                <th>Title</th>
                <th>Description</th>
                <th>Created At</th>
                <th>Updated At</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $sno='1';
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $sno . "</td>";
                echo "<td>" . $row['username'] . "</td>"; 
                echo "<td>" . $row['roles'] . "</td>"; // Display role from role_master table
                echo "<td>" . $row['title'] . "</td>";
                echo "<td>" . $row['description'] . "</td>";
                echo "<td>" . $row['created_at'] . "</td>";
                echo "<td>" . $row['updated_at'] . "</td>";
                echo "<td>
                        <a href='?action=delete&id=" . $row['request_id'] . "' class='btn btn-sm btn-danger'>Delete</a>
                      </td>";
                echo "</tr>";
                $sno++;
            }
            ?>
        </tbody>
    </table>
</div>

<!-- Bootstrap JS -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
    $(document).ready(function() {
        $('.editBtn').click(function() {
            var id = $(this).data('id');
            $.ajax({
                url: 'get_request.php',
                method: 'GET',
                data: { id: id },
                success: function(response) {
                    var data = JSON.parse(response);
                    $('#edit_request_id').val(data.request_id);
                    $('#edit_userid').val(data.userid);
                    $('#edit_roleid').val(data.roleid);
                    $('#edit_title').val(data.title);
                    $('#edit_description').val(data.description);
                    $('#edit_status').val(data.status);
                }
            });
        });

        $('#saveChangesBtn').click(function() {
            var formData = $('#editRequestForm').serialize();
            $.ajax({
                url: 'save_changes.php',
                method: 'POST',
                data: formData,
                success: function(response) {
                    // Handle success response
                    console.log(response);
                    $('#editRequestModal').modal('hide');
                    // Reload the page or update the table with the new data
                    location.reload();
                },
                error: function(xhr, status, error) {
                    // Handle error
                    console.error(xhr.responseText);
                }
            });
        });
    });
</script>

</body>
</html>
