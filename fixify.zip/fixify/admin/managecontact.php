<?php
// Include necessary files and establish database connection
include "home.php";
$con = mysqli_connect("localhost", "root", "", "fixify");

// Check if form is submitted for deleting contact
if (isset($_POST['action']) && $_POST['action'] == 'delete_contact') {
    $id = $_POST['delete_id'];

    // Delete contact from the database
    $sql = "DELETE FROM `contact` WHERE id='$id'";
    $res = mysqli_query($con, $sql);

    if ($res) {
        // Show delete success message
        echo '<div id="deleteSuccess" class="alert alert-success alert-dismissible fade show mt-1" role="alert">
            Contact deleted successfully!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>';
    } else {
        // Show delete error message
        echo '<div id="deleteError" class="alert alert-danger alert-dismissible fade show mt-1" role="alert">
            Error deleting contact: ' . mysqli_error($con) . '
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>';
    }
}

// Check if reply form is submitted
if (isset($_POST['reply_message'])) {
    // Get the recipient email and reply message
    $recipient_email = $_POST['recipient_email'];
    $reply_message = $_POST['reply_message'];

    // Send the reply using the SendinBlue API
    $sendinblue_api_key = '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'; // Update with your actual API key
    $url = "https://api.sendinblue.com/v3/smtp/email";

    // Data to be sent in the API request
   $data = array(
    'sender' => array('email' => 'fixify@gmail.com', 'name' => 'Fixify'),
    'to' => array(array('email' => $recipient_email)),
    'subject' => 'Reply Your Contact Fixify', // Add the subject here
    'htmlContent' => $reply_message
);

    $ch = curl_init($url);

// Set cURL options
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data)); // Send data as JSON
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',
    'api-key: ' . $sendinblue_api_key
));

// Execute cURL session
$response = curl_exec($ch);

    // Check for errors
  if ($response === false) {
    // Show reply error message
    echo '<div id="replyError" class="alert alert-danger alert-dismissible fade show mt-1" role="alert">
        Error sending reply: ' . curl_error($ch) . '
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>';
} else {
  

    // Show reply success message if no errors
    echo '<div id="replySuccess" class="alert alert-success alert-dismissible fade show mt-1" role="alert">
        Reply sent successfully!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>';
}

// Close cURL session
curl_close($ch);
}

// Fetch contacts from contact table
$sql_contacts = "SELECT * FROM `contact`";
$result_contacts = mysqli_query($con, $sql_contacts);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fixify</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Manage Contact</h2>
        <hr>
        <h3>Contact List</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Subject</th>
                    <th>Message</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result_contacts->num_rows > 0) {
                    while ($row_contact = $result_contacts->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row_contact['name'] . "</td>";
                        echo "<td>" . $row_contact['email'] . "</td>";
                        echo "<td>" . $row_contact['subject'] . "</td>";
                        echo "<td>" . $row_contact['message'] . "</td>";
                        echo "<td>";
                        echo "<form action='' method='POST'>";
                        echo "<input type='hidden' name='action' value='delete_contact'>";
                        echo "<input type='hidden' name='delete_id' value='" . $row_contact['id'] . "'>";
                        echo "<button type='submit' class='btn btn-danger'>Delete</button>";
                        echo "</form>";
                        echo "<button type='button' class='btn btn-primary' onclick='openReplyModal(\"" . $row_contact['email'] . "\")'>Reply</button>"; // Button to open reply modal
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No contacts found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Custom JavaScript for Delete Confirmation Pop-up and Reply Modal -->
    <script>
        // Function to show success or error message for 5 seconds
        function showTemporaryMessage(messageId) {
            $('#' + messageId).show();
            setTimeout(function() {
                $('#' + messageId).hide();
            }, 5000); // 5 seconds
        }

        // Function to open reply modal and set recipient email
        function openReplyModal(email) {
            $('#replyModal').modal('show');
            $('#recipientEmail').val(email); // Set recipient email in the modal
        }

        // Optional: Close the modal after sending reply
        $('#sendReplyBtn').click(function() {
            $('#replyModal').modal('hide');
        });

        // Automatically close any alert with class .alert-dismissible after 5 seconds
        $('.alert-dismissible').each(function() {
            var alert = $(this);
            window.setTimeout(function() {
                alert.fadeTo(500, 0).slideUp(500, function() {
                    $(this).remove();
                });
            }, 5000); // 5 seconds
        });
    </script>

    <!-- Reply Modal -->
    <div class="modal fade" id="replyModal" tabindex="-1" role="dialog" aria-labelledby="replyModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="replyModalLabel">Reply to Contact</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="" method="POST">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="recipientEmail">Recipient Email:</label>
                            <input type="email" class="form-control" id="recipientEmail" name="recipient_email" readonly>
                        </div>
                        <div class="form-group">
                            <label for="replyMessage">Reply Message:</label>
                            <textarea class="form-control" id="replyMessage" name="reply_message" rows="5" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" id="sendReplyBtn" class="btn btn-primary">Send Reply</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
