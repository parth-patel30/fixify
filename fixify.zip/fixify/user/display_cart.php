<?php
// Include the home.php file that contains necessary configurations or functions
include "home.php";

// Establish a connection to the database
$con = mysqli_connect("localhost", "root", "", "fixify");

// Check if the connection is successful
if (!$con) {
    // If connection fails, display an error message and terminate the script
    die("Connection failed: " . mysqli_connect_error());
}

// Initialize $cartData and $totalPriceSum variables
$cartData = []; // Initialize as an empty array to store cart items
$totalPriceSum = 0; // Initialize as zero to calculate the total price of items in the cart

// Check if the user ID is set in the session (i.e., user is logged in)
if (isset($_SESSION['user_id'])) {
    // Get the user ID from the session
    $userId = $_SESSION['user_id'];

    // Retrieve cart data for the user from the database
    $cartQuery = "SELECT services.servicename, services.price, cart.quantity FROM cart INNER JOIN services ON cart.serviceid = services.serviceid WHERE cart.id = $userId";
    $cartResult = mysqli_query($con, $cartQuery);

    // Check if there are items in the cart for the user
    if (mysqli_num_rows($cartResult) > 0) {
        // Loop through each row in the cart result
        while ($row = mysqli_fetch_assoc($cartResult)) {
            // Add each cart item to the $cartData array
            $cartData[] = $row;
            // Calculate and update the total price with the price of each item multiplied by its quantity
            $totalPriceSum += $row['price'] * $row['quantity'];
        }
    }

    // Fetch user address from the database (assuming there's a column named 'address' in the 'users' table)
    $userAddress = "";
    $addressQuery = "SELECT address FROM users WHERE id = $userId"; // Corrected column name to 'id'
    $addressResult = mysqli_query($con, $addressQuery);
    if (mysqli_num_rows($addressResult) > 0) {
        $row = mysqli_fetch_assoc($addressResult);
        $userAddress = $row['address'];
    }
} else {
    // Redirect to login page if user ID is not set in the session
    header("Location: login.php");
    exit(); // Terminate the script
}

// Check if the payment form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get payment form data
    $paymentDate = $_POST['date'];
    $paymentTime = $_POST['time'];
    $paymentAddress = $_POST['address'];
    $paymentMethod = $_POST['payment_method'];

    // Additional payment data can be retrieved and processed as needed

    // Handle payment processing based on the selected payment method
    if ($paymentMethod == 'credit_card') {
        // Process credit card payment using Stripe or other payment gateway
        require_once 'stripe/init.php'; // Include Stripe library
        \Stripe\Stripe::setApiKey('your_stripe_api_key'); // Set your Stripe API key

        try {
            // Create a payment intent with Stripe
            $paymentIntent = \Stripe\PaymentIntent::create([
                'amount' => $totalPriceSum * 100, // Amount in cents
                'currency' => 'usd',
                'description' => 'Payment for services',
                'payment_method' => $_POST['stripeToken'], // Payment method obtained from Stripe.js
                'confirmation_method' => 'manual',
                'confirm' => true,
            ]);

            // Payment successful
            $paymentSuccess = true;
        } catch (\Stripe\Exception\CardException $e) {
            // Payment failed
            $paymentSuccess = false;
            $error = $e->getError()->message;
        }
    } elseif ($paymentMethod == 'net_banking') {
        // Process net banking payment
        // Add your net banking payment processing code here
        $paymentSuccess = true; // Simulate a successful payment for demonstration purposes
    } else {
        // Invalid payment method selected
        $paymentSuccess = false;
        $error = "Invalid payment method selected.";
    }

    // If payment is successful, proceed to store payment data in the database
    if ($paymentSuccess) {
        // Insert payment data into the database
        $insertQuery = "INSERT INTO payments (user_id, payment_date, payment_time, payment_address, payment_method) VALUES ('$userId', '$paymentDate', '$paymentTime', '$paymentAddress', '$paymentMethod')";
        if (mysqli_query($con, $insertQuery)) {
            echo "<script>alert('Payment successful. Data stored in the database.');</script>";
        } else {
            echo "<script>alert('Error: " . mysqli_error($con) . "');</script>";
        }
    } else {
        echo "<script>alert('Payment failed: $error');</script>";
    }
}

// Close the database connection
mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Include necessary CSS and JS libraries in the head section -->

    <!-- Stripe Script -->
 <script src="http://js.stripe.com/v3/"></script>

    <!-- Stripe Script -->
<script src="https://cdn.jsdelivr.net/npm/stripe@latest"></script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Bootstrap DateTimePicker CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" rel="stylesheet">
</head>
<body>
    <!-- Start of HTML body content -->
    <div class="container">
        <h1 class="text-center">Payment</h1>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">Review Your Order</div>
                    <div class="card-body">
                        <?php if (!empty($cartData)): ?>
                            <!-- Display cart items in a table if the cart is not empty -->
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Service Name</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Total Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($cartData as $item): ?>
                                        <tr>
                                            <!-- Display each item's details in a row -->
                                            <td><?php echo $item['servicename']; ?></td>
                                            <td>$<?php echo $item['price']; ?></td>
                                            <td><?php echo $item['quantity']; ?></td>
                                            <td>$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <tr>
                                        <!-- Display the total price of all items in the cart -->
                                        <td colspan="3"><strong>Total Price</strong></td>
                                        <td><strong>$<?php echo number_format($totalPriceSum, 2); ?></strong></td>
                                    </tr>
                                </tbody>
                            </table>
                            <!-- Payment form for processing payment -->
                            <form id="payment-form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                <div class="form-group">
                                    <label for="date">Date</label>
                                    <input type="date" class="form-control" id="date" name="date" required min="<?php echo date('Y-m-d'); ?>" max="<?php echo date('Y-m-d', strtotime('+1 month')); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="time">Time</label>
                                    <input type="text" id="timePicker" class="form-control" name="time">
                                </div>
                                <div class="form-group">
                                    <label for="address">Address</label>
                                    <input type="text" class="form-control" id="address" name="address" value="<?php echo $userAddress; ?>" placeholder="Enter your address" required>
                                </div>
                                <div class="form-group">
                                    <label for="payment_method">Payment Method</label>
                                    <select class="form-control" id="payment_method" name="payment_method" required>
                                        <option value="credit_card">Credit Card</option>
                                        <option value="net_banking">Net Banking</option>
                                        <!-- Add more payment methods as needed -->
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary" id="submit-button">Pay Now</button>
                            </form>
                        <?php else: ?>
                            <!-- Display a message if the cart is empty -->
                            <p>Your cart is empty.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Include necessary JavaScript libraries and scripts -->
    
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- Stripe JavaScript library -->
    <script src="https://js.stripe.com/v3/"></script>
    <!-- Your custom JavaScript for Stripe integration -->
    <script>
        // Create a Stripe client
        var stripe = Stripe('pk_test_51P5OvvSCXKXhIpVgSAoXhgkuNXmGN5GXHY9rw556JHSc1VjP1E9VRAPWLL9KpNgUUYwks35lofEU9qnZ7kvcvbQc00eCRlwCo0'); // Replace 'your_stripe_public_key' with your actual Stripe public key

        // Create an instance of Elements
        var elements = stripe.elements();

        // Custom styling can be passed to options when creating an Element
        var style = {
            base: {
                color: '#32325d',
                lineHeight: '18px',
                fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
                fontSmoothing: 'antialiased',
                fontSize: '16px',
                '::placeholder': {
                    color: '#aab7c4'
                }
            },
            invalid: {
                color: '#fa755a',
                iconColor: '#fa755a'
            }
        };

        // Create an instance of the card Element
        var card = elements.create('card', {
            style: style,
            hidePostalCode: true // Optionally hide the postal code input
        });

        // Add an instance of the card Element into the `card-element` div
        card.mount('#card-element');

        // Handle form submission
        var form = document.getElementById('payment-form');
        form.addEventListener('submit', function (event) {
            event.preventDefault();

            // Disable the submit button to prevent multiple submissions
            document.getElementById('submit-button').disabled = true;

            // Create payment method using Stripe.js
            stripe.createPaymentMethod({
                type: 'card',
                card: card,
                billing_details: {
                    // Include additional billing details if needed
                    name: document.getElementById('name_on_card').value,
                    // Add more billing details as needed
                },
            }).then(function (result) {
                if (result.error) {
                    // Show error to your customer
                    var errorElement = document.getElementById('card-errors');
                    errorElement.textContent = result.error.message;

                    // Enable the submit button to allow retrying payment
                    document.getElementById('submit-button').disabled = false;
                } else {
                    // Stripe PaymentMethod was created successfully
                    // Include the payment method ID in the form and submit
                    var paymentMethodInput = document.createElement('input');
                    paymentMethodInput.setAttribute('type', 'hidden');
                    paymentMethodInput.setAttribute('name', 'stripeToken');
                    paymentMethodInput.setAttribute('value', result.paymentMethod.id);
                    form.appendChild(paymentMethodInput);

                    // Submit the form
                    form.submit();
                }
            });
        });
    </script>
</body>
</html>
