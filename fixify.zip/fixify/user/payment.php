<?php
session_start(); // Start the session

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$con = mysqli_connect("localhost", "root", "", "fixify");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Initialize $cartData and $totalPriceSum
$cartData = []; // Initialize as an empty array
$totalPriceSum = 0; // Initialize as zero

// Retrieve cart data for the user from the database
$userId = $_SESSION['user_id'];
$cartQuery = "SELECT services.servicename, services.price, cart.quantity FROM cart INNER JOIN services ON cart.serviceid = services.serviceid WHERE cart.id = $userId";
$cartResult = mysqli_query($con, $cartQuery);

if (mysqli_num_rows($cartResult) > 0) {
    while ($row = mysqli_fetch_assoc($cartResult)) {
        $cartData[] = $row;
        $totalPriceSum += $row['price'] * $row['quantity']; // Update total price with quantity
    }
}

// Fetch user address from the database
$userAddress = "";
$addressQuery = "SELECT address FROM users WHERE id = $userId"; // Corrected column name to 'id'
$addressResult = mysqli_query($con, $addressQuery);
if (mysqli_num_rows($addressResult) > 0) {
    $row = mysqli_fetch_assoc($addressResult);
    $userAddress = $row['address'];
}

// Close database connection
mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <style>
      

        @media (max-width: 768px) {
            .payment-form {
                max-width: 100%;

            }
        }
    </style>
    <script src="https://js.stripe.com/v3/"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1 class="text-center">Payment</h1>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Review Your Order</div>
                    <div class="card-body">
                        <?php if (!empty($cartData)): ?>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Service Name</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Total Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($cartData as $item): ?>
                                        <tr>
                                            <td><?php echo $item['servicename']; ?></td>
                                            <td>₹<?php echo $item['price']; ?></td>
                                            <td><?php echo $item['quantity']; ?></td>
                                            <td>₹<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                                            <input type="hidden" name="service_id[]" value="<?php echo implode(',', array_column($cartData, 'serviceid')); ?>">
                                        </tr>
                                    <?php endforeach; ?>
                                    <tr>
                                        <td colspan="3"><strong>Total Price</strong></td>
                                        <td><strong>₹<?php echo number_format($totalPriceSum, 2); ?></strong></td>
                                    </tr>
                                </tbody>
                            </table>
                            <form action="process_payment.php" method="post">
                                <div class="form-group">
                                    <label for="date">Date</label>
                                    <input type="date" class="form-control" id="date" name="date" required min="<?php echo date('Y-m-d'); ?>" max="<?php echo date('Y-m-d', strtotime('+1 month')); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="time">Time</label>
                                    <input type="text" id="timePicker" class="form-control" name="time">
                                </div>
                                <div class="form-group">
                                    <label for="address">Address</label>
                                    <input type="text" class="form-control" id="address" name="address" value="<?php echo $userAddress; ?>" placeholder="Enter your address" required>
                                </div>
    

                                <script src="https://checkout.stripe.com/checkout.js" class="stripe-button" data-key="pk_test_51P5OvvSCXKXhIpVgSAoXhgkuNXmGN5GXHY9rw556JHSc1VjP1E9VRAPWLL9KpNgUUYwks35lofEU9qnZ7kvcvbQc00eCRlwCo0" 
                                data-amount="<?php echo $totalPriceSum * 100; ?>" 
                                data-name="Fixify" 
                                data-description="Payment for services" 
                                data-currency="inr" 
                                data-locale="auto"></script>
                            </form>
                        <?php else: ?>
                            <p>Your cart is empty.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
    <script>
   

          $(document).ready(function () {
            $('#timePicker').datetimepicker({
                format: 'LT',
                stepping: 30,
                icons: {
                    time: 'fa fa-clock',
                    date: 'fa fa-calendar',
                    up: 'fa fa-chevron-up',
                    down: 'fa fa-chevron-down',
                    previous: 'fa fa-chevron-left',
                    next: 'fa fa-chevron-right',
                    today: 'fa fa-calendar-check-o',
                    clear: 'fa fa-trash',
                    close: 'fa fa-times'
                },
                useCurrent: false
            });

            $('#date').on('change', function () {
                var selectedDate = new Date($(this).val());
                var currentDate = new Date();
                var currentHour = currentDate.getHours();

                if (selectedDate.toDateString() === currentDate.toDateString()) {
                    currentDate.setHours(currentHour + 1);
                    $('#timePicker').datetimepicker('minDate', currentDate);
                    $('#timePicker').datetimepicker('maxDate', '20:59');
                    var formattedTime = moment(currentDate).format('h:mm A');
                    $('#timePicker').val(formattedTime);
                } else {
                    $('#timePicker').datetimepicker('minDate', '10:00');
                    $('#timePicker').datetimepicker('maxDate', '20:59');
                }
            });
        });
           $('#paymentForm').submit(function (e) {
                e.preventDefault(); // Prevent default form submission
                var formData = $(this).serialize(); // Serialize form data
  // Set selected date, time, and payment mode values
            $('#selected_date').val($('#date').val());
            $('#selected_time').val($('#timePicker').val());
                // Send AJAX request to process_payment.php
                $.ajax({
                    type: 'POST',
                    url: 'process_payment.php',
                    data: formData,
                    success: function (response) {
                        // Handle success response
                        console.log(response);
                        // You can show a success message or perform other actions here
                    },
                    error: function (error) {
                        // Handle error response
                        console.log(error.responseText);
                    }
                });
            });
        
  
    $(document).ready(function () {
        // Existing JavaScript code

        $('#paymentForm').submit(function (e) {
            e.preventDefault(); // Prevent default form submission
            var formData = $(this).serialize(); // Serialize form data

            // Set selected date, time, and payment mode values
            $('#selected_date').val($('#date').val());
            $('#selected_time').val($('#timePicker').val());
            $('#payment_mode').val('Stripe'); // Assuming payment mode is Stripe

            // Send AJAX request to process_payment.php
            $.ajax({
                type: 'POST',
                url: 'process_payment.php',
                data: formData,
                success: function (response) {
                    // Handle success response
                    console.log(response);
                    // You can show a success message or perform other actions here
                },
                error: function (error) {
                    // Handle error response
                    console.log(error.responseText);
                }
            });
        });
    });

    </script>
</body>
</html>
