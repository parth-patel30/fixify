<?php
ob_start();

include "home.php";

$con = mysqli_connect("localhost", "root", "", "fixify");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

function getOrderData($con, $userId) {
    $query = "SELECT orders.*, services.servicename, services.image AS service_image, 
              ratings.rating AS order_rating, ratings.feedback AS order_feedback
              FROM orders 
              LEFT JOIN services ON orders.serviceid = services.serviceid 
              LEFT JOIN ratings ON orders.order_id = ratings.order_id 
              WHERE orders.userid = $userId 
              ORDER BY orders.order_id DESC";
    $result = mysqli_query($con, $query);

    $orderData = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $orderData[] = $row;
    }

    return $orderData;
}

$userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['orderId']) && isset($_POST['rating']) && isset($_POST['feedback'])) {
    // Form submitted, handle feedback insertion or update
    $orderId = $_POST['orderId'];
    $rating = $_POST['rating'];
    $feedback = $_POST['feedback'];

    // Fetch service_id based on order_id
    $serviceQuery = "SELECT serviceid FROM orders WHERE order_id = $orderId";
    $serviceResult = mysqli_query($con, $serviceQuery);
    if ($serviceRow = mysqli_fetch_assoc($serviceResult)) {
        $serviceId = $serviceRow['serviceid'];

        // Check if the user has already given feedback for this order
        $checkQuery = "SELECT * FROM ratings WHERE order_id = $orderId AND user_id = $userId";
        $checkResult = mysqli_query($con, $checkQuery);

        if (mysqli_num_rows($checkResult) > 0) {
            // Feedback already exists, update it
            $updateQuery = "UPDATE ratings SET rating = ?, feedback = ? WHERE order_id = ? AND user_id = ?";
            $stmt = mysqli_prepare($con, $updateQuery);
            mysqli_stmt_bind_param($stmt, "isis", $rating, $feedback, $orderId, $userId);
            if (mysqli_stmt_execute($stmt)) {
                echo "Feedback updated successfully!";
            } else {
                echo "Error updating feedback: " . mysqli_error($con);
            }
            mysqli_stmt_close($stmt);
        } else {
            // Feedback doesn't exist, insert new feedback
            $insertQuery = "INSERT INTO ratings (order_id, user_id, service_id, rating, feedback, created_at) 
                   VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
            $stmt = mysqli_prepare($con, $insertQuery);
            mysqli_stmt_bind_param($stmt, "iiids", $orderId, $userId, $serviceId, $rating, $feedback);
            if (mysqli_stmt_execute($stmt)) {
                echo "Feedback inserted successfully!";
            } else {
                echo "Error inserting feedback: " . mysqli_error($con);
            }
            mysqli_stmt_close($stmt);
        }
    } else {
        echo "Error fetching service ID for the order.";
    }
}

$orderData = [];
if ($userId) {
    $orderData = getOrderData($con, $userId);
}

mysqli_close($con);
ob_end_flush();
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Your CSS styles here */
        .service-image {
            max-width: 100px;
            height: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (empty($orderData)): ?>
            <div class="empty-cart-container">
                
                <h1 class="empty-cart-text">No orders found</h1>
                <p>You have not placed any orders yet.</p>
                <a href="index.php" class="btn btn-home">Back to Home</a>
            </div>
        <?php else: ?>
            <h1 class="text-center">Orders</h1>
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th>Service Name</th>
                        <th>Image</th>
                        <th>Price</th>
                        <th>Payment Status</th>
                        <th>Download Invoice</th>
                        <th>Leave Feedback</th> 
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orderData as $order): ?>
                        <tr>
                            <td><?php echo isset($order['servicename']) ? $order['servicename'] : ''; ?></td>
                            <td>
                                <?php if (isset($order['service_image']) && !empty($order['service_image'])): ?>
                                    <?php $imagePath = "../partner/" . $order['service_image']; ?>
                                    <img src="<?php echo $imagePath; ?>" alt="<?php echo isset($order['servicename']) ? $order['servicename'] : ''; ?>" style="height: 80px; width: 80px;">
                                <?php else: ?>
                                    No Image Available
                                <?php endif; ?>
                            </td>
                            <td><?php echo isset($order['total_price']) ? $order['total_price'] : ''; ?></td>
                            <td><?php echo isset($order['paymentstatus']) ? $order['paymentstatus'] : ''; ?></td>
                            <td><a href="generate_pdf.php?orderid=<?php echo $order['order_id']; ?>" target="_blank">Download PDF</a></td>
                            <td>
                                <?php if ($order['status'] == 1): ?>
                                    <button class="btn btn-primary" data-toggle="modal" data-target="#feedbackModal" data-orderid="<?php echo $order['order_id']; ?>" data-feedback="<?php echo isset($order['order_feedback']) ? $order['order_feedback'] : ''; ?>" data-serviceid="<?php echo isset($order['serviceid']) ? $order['serviceid'] : ''; ?>" data-rating="<?php echo isset($order['order_rating']) ? $order['order_rating'] : '0'; ?>">Leave Feedback</button>
                                <?php else: ?>
                                    <!-- Display some placeholder or empty cell -->
                                <?php endif; ?>
                            </td>
                           
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div class="modal fade" id="feedbackModal" tabindex="-1" role="dialog" aria-labelledby="feedbackModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="feedbackModalLabel">Add Rating and Feedback</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="feedbackForm" method="POST">
                            <input type="hidden" id="orderId" name="orderId" value="">
                            
                            <div class="form-group">
                                <label for="rating">Rating:</label>
                                <div class="rating-container">
                                    <i class="far fa-star" data-rating="1"></i>
                                    <i class="far fa-star" data-rating="2"></i>
                                    <i class="far fa-star" data-rating="3"></i>
                                    <i class="far fa-star" data-rating="4"></i>
                                    <i class="far fa-star" data-rating="5"></i>
                                </div>
                                <input type="hidden" id="rating" name="rating" value="1" required>
                            </div>
                            <div class="form-group">
                                <label for="feedback">Feedback:</label>
                                <textarea id="feedback" name="feedback" rows="3" class="form-control" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            // Star rating functionality
            $('.rating-container i').on('click', function() {
                var ratingValue = parseInt($(this).data('rating'));
                $('#rating').val(ratingValue);

                // Update star colors
                $('.rating-container i').each(function() {
                    var currentRating = parseInt($(this).data('rating'));
                    if (currentRating <= ratingValue) {
                        $(this).removeClass('far').addClass('fas');
                    } else {
                        $(this).removeClass('fas').addClass('far');
                    }
                });
            });

            // Set order ID, existing feedback, and rating when feedback modal is opened
            $('#feedbackModal').on('show.bs.modal', function(event) {
                var button = $(event.relatedTarget);
                var orderId = button.data('orderid');
                var existingFeedback = button.data('feedback');
                var existingRating = button.data('rating');

                $('#orderId').val(orderId);
                $('#feedback').val(existingFeedback);
                $('#rating').val(existingRating);

                // Update star colors for existing rating
                $('.rating-container i').each(function() {
                    var currentRating = parseInt($(this).data('rating'));
                    if (currentRating <= existingRating) {
                        $(this).removeClass('far').addClass('fas');
                    } else {
                        $(this).removeClass('fas').addClass('far');
                    }
                });
            });

            // Handle form submission
            $('#feedbackForm').submit(function(event) {
                event.preventDefault(); // Prevent form submission

                // Submit the form using AJAX
                $.post(window.location.href, $('#feedbackForm').serialize(), function(data) {
                    // Display the response message (e.g., Feedback inserted successfully)
                    $('#feedbackModal').modal('hide'); // Close the modal
                    location.reload(); // Reload the page to update ratings
                });
            });
        });
    </script>
</body>
</html>
