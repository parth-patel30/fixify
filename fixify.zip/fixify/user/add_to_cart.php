<?php
ob_start(); // Enable output buffering

include 'home.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
  header("Location: ../index.php");
  exit;
}

// Establish database connection
$con = mysqli_connect("localhost", "root", "", "fixify");

// Check if the connection was successful
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (isset($_POST['service_id']) && !empty($_POST['service_id'])) {
    $userId = $_SESSION['user_id'];
    $serviceId = $_POST['service_id'];

    // Retrieve service information from the database
    $query = "SELECT * FROM services WHERE serviceid = $serviceId";
    $result = mysqli_query($con, $query);

    if (!$result) {
      echo "Error in SQL query: " . mysqli_error($con);
      exit;
    }

    if (mysqli_num_rows($result) > 0) {
      $row = mysqli_fetch_assoc($result);
      $serviceName = $row['servicename'];
      $price = $row['price'];
      $qu = '1';
      $insertQuery = "INSERT INTO cart (id, serviceid, service_name, total_price, quantity) 
                      VALUES ('$userId', '$serviceId', '$serviceName', '$price', '$qu')";

      if (mysqli_query($con, $insertQuery)) {
        // Redirect after successful insertion
        header("location:index.php");
        exit;
      } else {
        echo "Error adding item to cart: " . mysqli_error($con);
      }
    } else {
      echo "Error retrieving service information. Service ID: " . $serviceId;
    }
  } else {
    echo "Service ID is not set or empty.";
  }
}

// Close database connection
mysqli_close($con);

// Flush the output buffer (important after redirection)
ob_end_flush();
?>
