// Add request modal
const addRequestModal = document.getElementById('addRequestModal');
const addRequestBtn = document.querySelector('button');
const closeAddRequestSpan = document.getElementsByClassName('close')[0];

addRequestBtn.onclick = function () {
    addRequestModal.style.display = 'block';
};

closeAddRequestSpan.onclick = function () {
    addRequestModal.style.display = 'none';
};

window.onclick = function (event) {
    if (event.target === addRequestModal) {
        addRequestModal.style.display = 'none';
    }
};

// Edit request modal
const editRequestModal = document.getElementById('editRequestModal');
const editRequestSpans = document.getElementsByClassName('editRequest');
const closeEditRequestSpan = document.getElementsByClassName('close')[1];

for (let span of editRequestSpans) {
    span.onclick = function () {
        editRequestModal.style.display = 'block';
        const requestId = this.getAttribute('data-id');
        document.getElementById('editRequestId').value = requestId;
    };
}

closeEditRequestSpan.onclick = function () {
    editRequestModal.style.display = 'none';
};

window.onclick = function (event) {
    if (event.target === editRequestModal) {
        editRequestModal.style.display = 'none';
    }
};

// Delete request modal
const deleteRequestModal = document.getElementById('deleteRequestModal');
const deleteRequestSpans = document.getElementsByClassName('deleteRequest');
const closeDeleteRequestSpan = document.getElementsByClassName('close')[2];

for (let span of deleteRequestSpans) {
    span.onclick = function () {
        deleteRequestModal.style.display = 'block';
        const requestId = this.getAttribute('data-id');
        document.getElementById('deleteRequestId').value = requestId;
    };
}

closeDeleteRequestSpan.onclick = function () {
    deleteRequestModal.style.display = 'none';
};

window.onclick = function (event) {
    if (event.target === deleteRequestModal) {
        deleteRequestModal.style.display = 'none';
    }
};
