<?php
require_once('tcpdf/tcpdf.php');

// Initialize TCPDF object
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Set document information
$pdf->SetCreator('Your Creator');
$pdf->SetAuthor('Your Author');
$pdf->SetTitle('Order Details PDF');
$pdf->SetSubject('Order Details');
$pdf->SetKeywords('Order, Details, PDF');


$header_image_path = 'fixify12.png';

// Check if the image file exists and use it for header
if (file_exists($header_image_path)) {
  $pdf->SetHeaderData($header_image_path, 10, 'Fixify', 'fixify@gmail.com');
} else {
  // Handle missing image (optional)
  echo "Error: Header image file not found.";
}
// Set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, 'Fixify', 'fixify@gmail.com');

// Set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// Set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// Set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// Set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// Set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// Set font
$pdf->SetFont('helvetica', '', 15);

// Add a page
$pdf->AddPage();

// Include Bootstrap CSS in the PDF
$html = '<head><link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"></head>';

// Check if orderid is provided in the URL
if (isset($_GET['orderid'])) {
    $orderid = $_GET['orderid'];

    // Fetch order details from the database
    $con = mysqli_connect("localhost", "root", "", "fixify");
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $query = "SELECT orders.*, services.servicename, users.username 
              FROM orders 
              LEFT JOIN services ON orders.serviceid = services.serviceid 
              LEFT JOIN users ON orders.userid = users.id 
              WHERE orders.order_id = $orderid";
    $result = mysqli_query($con, $query);

    if (mysqli_num_rows($result) > 0) {
        $order = mysqli_fetch_assoc($result);

        // Example of displaying order details in PDF with Bootstrap and JS
        $html .= '<div class="container mt-5">';
       $html .= '<h1 class="text-center mb-4" style="text-align: center; margin-bottom: 20px;">Order Details</h1><br><rb>';

        $html .= '<div class="row">';
        $html .= '<div class="col-md-6" style="width: 50%; float: left; padding: 10px;">';
        $html .= '<h4>User Name: ' . $order['username'] . '</h4>';
        $html .= '<h4>Address: ' . $order['address'] . '</h4>';
        $html .= '<h4>Select Time: ' . $order['select_time'] . '</h4>';
        $html .= '<h4>Select Date: ' . $order['select_date'] . '</h4>';
        $html .= '</div>';

       $html .= '<div class="container mt-5" style="padding: 20px;">';
$html .= '<table class="table" style="border: 1px solid #ddd; width: 100%;">';
$html .= '<thead>';
$html .= '<tr style="background-color: #f2f2f2; font-weight: bold;">'; // Styled header row
$html .= '<th>Service Name</th>';
$html .= '<th style="text-align: center;">Quantity</th>';
$html .= '<th style="text-align: center;">Payments Status</th>';
$html .= '<th style="text-align: right;">Price</th>';
$html .= '</tr>';
$html .= '</thead>';
$html .= '<tbody>';
$html .= '<tr>';
$html .= '<td>' . $order['servicename'] . '</td>';
$html .= '<td style="text-align: center;">' . $order['quantity'] . '</td>'; // Center align quantity
$html .= '<td style="text-align: center;">' . $order['paymentstatus'] . '</td>';
$html .= '<td style="text-align: right;">' . $order['total_price'] . '</td>'; // Right align price

        $html .= '</tr>';
        // You can add more rows for additional services if needed
        $html .= '</tbody>';
        $html .= '</table>';
        $html .= '</div>';
        $html .= '</div>';

        $html .= '</div>';

        
        $pdf->writeHTML($html, true, false, true, false, '');

        // Add a footer
        $footer = '<table style="width: 100%; text-align: center;"><tr><td>Page ' . $pdf->getAliasNumPage() . ' of ' . $pdf->getAliasNbPages() . '</td></tr></table>';
        $pdf->setFooterData('', 0, '', $footer);

        // Close database connection
        mysqli_close($con);
    } else {
        echo "No order found.";
    }

    // Close and output PDF document
    $pdf->Output('order_details.pdf', 'I');

    // Stop script execution
    exit;
} else {
    echo "Order ID not provided.";
}
?>
