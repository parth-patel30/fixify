<?php
ob_start();

include "home.php";

$con = mysqli_connect("localhost", "root", "", "fixify");

// Check if the connection was successful
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

function getCartData($con, $userId) {
    $query = "SELECT services.serviceid, services.servicename, services.image, services.price, IFNULL(SUM(cart.quantity), 0) AS service_count, IFNULL(SUM(cart.total_price), 0) AS final_price
            FROM services
            LEFT JOIN cart ON services.serviceid = cart.serviceid AND cart.id = $userId
            GROUP BY services.serviceid, services.servicename, services.image, services.price";
    $result = mysqli_query($con, $query);

    $cartData = [];
    while ($row = mysqli_fetch_assoc($result)) {
        // Get the actual count of the service in the cart
        $serviceId = $row['serviceid'];
        $actualCountQuery = "SELECT IFNULL(SUM(quantity), 0) AS actual_count FROM cart WHERE serviceid = $serviceId AND id = $userId";
        $actualCountResult = mysqli_query($con, $actualCountQuery);
        $actualCountRow = mysqli_fetch_assoc($actualCountResult);
        $row['service_count'] = intval($actualCountRow['actual_count']);

        $cartData[] = $row;
    }

    return $cartData;
}

function removeFromCart($con, $serviceId, $userId) {
    $query = "DELETE FROM cart WHERE serviceid = $serviceId AND id = $userId";
    $result = mysqli_query($con, $query);
    return $result;
}

$userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

// Check if Remove button is clicked
if (isset($_POST['remove_from_cart']) && isset($_POST['service_id'])) {
    $serviceIdToRemove = $_POST['service_id'];
    $removeResult = removeFromCart($con, $serviceIdToRemove, $userId);
    if ($removeResult) {
        // Redirect to cart page to refresh the cart data after removal
        header("Location: cart.php");
        exit();
    } else {
        echo "Failed to remove item from cart.";
    }
}

if ($userId) {
    $cartData = getCartData($con, $userId);
} else {
    $cartData = [];
}

// Calculate the total price of all items in the cart and store it in $totalPriceSum
$totalPriceSum = 0;
if (!empty($cartData)) {
    foreach ($cartData as $item) {
        $totalPriceSum += $item['final_price'];
    }
}

// Store cart data in session for use in payment page
$_SESSION['cart_data'] = $cartData;

// Close database connection
mysqli_close($con);

// Flush the output buffer (important after redirection)
ob_end_flush();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .empty-cart-container {
            max-width: 600px;
            margin: 0 auto;
            text-align: center;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .empty-cart-icon {
            font-size: 72px;
            color: grey;
            margin-bottom: 20px;
        }

        .empty-cart-text {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .btn-home {
            color: #fff;
            background-color: #343a40;
            border-color: white;
        }

        .btn-home:hover {
            color: #343a40;
            background-color: #fff;
            border-color: black;
        }

        .quantity-input {
            display: flex;
            align-items: center;
            justify-content: space-between;
            max-width: 100px;
            margin: 0 auto;
        }

        .quantity-btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        .quantity-btn:hover {
            background-color: #0056b3;
        }

        .quantity-value {
            border: 1px solid #ccc;
            border-radius: 5px;
            font-weight: bold;
        }

        .final-price {
            font-weight: bold;
        }

        .total-price {
            font-size: 20px;
            font-weight: bold;
        }
        .quantity-input {
    display: flex;
    align-items: center;
    justify-content: center;
    max-width: 150px;
    margin: 0 auto;
}

.quantity-btn {
    width: 30px;
    height: 30px;
    font-size: 16px;
    border-radius: 20%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.quantity-value {
    width: 50px;
    text-align: center;
    font-weight: bold;
    margin: 0 10px;
}


    </style>
</head>

<body>
    <div class="container">
        <?php if ($totalPriceSum == 0): ?>
            <div class="empty-cart-container">
                <i class="fas fa-shopping-cart empty-cart-icon"></i>
                <h1 class="empty-cart-text">Your cart is empty</h1>
                <p>Please add items to your cart to proceed.</p>
                <a href="index.php" class="btn btn-home">Back to Home</a>
            </div>
        <?php else: ?>
            <h1 class="text-center">Cart</h1>
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th>Service Name</th>
                        <th>Image</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Final Price</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cartData as $item): ?>
                        <tr style="display: <?php echo $item['service_count'] > 0 ? '' : 'none'; ?>">
                            <td><?php echo isset($item['servicename']) ? $item['servicename'] : ''; ?></td>
                            <td>
                                <?php if (isset($item['image']) && !empty($item['image'])): ?>
                                    <img src="../partner/<?php echo $item['image']; ?>" alt="<?php echo isset($item['servicename']) ? $item['servicename'] : ''; ?>" style="height: 80px; width: 80px;">
                                <?php else: ?>
                                    No Image Available
                                <?php endif; ?>
                            </td>
                            <td>₹<?php echo isset($item['price']) ? $item['price'] : ''; ?></td>
                            <td>
                                <div class="quantity-input">
    <button class="btn btn-outline-primary quantity-btn" onclick="updateQuantity(<?php echo $item['serviceid']; ?>, -1)">-</button>
    <input type="text" class="form-control quantity-value" id="quantity<?php echo $item['serviceid']; ?>" value="<?php echo $item['service_count']; ?>" readonly>
    <button class="btn btn-outline-primary quantity-btn" onclick="updateQuantity(<?php echo $item['serviceid']; ?>, 1)">+</button>
</div>

                                   
                                    
                            </td>
                            <td class="final-price">₹<?php echo isset($item['final_price']) ? $item['final_price'] : ''; ?></td>
                            <td>
                                <form method="POST" action="">
                                    <input type="hidden" name="service_id" value="<?php echo isset($item['serviceid']) ? $item['serviceid'] : ''; ?>">
                                    <button type="submit" class="btn btn-danger" name="remove_from_cart">Remove</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="4"></td>
                        <td class="total-price">Total Price: ₹<?php echo number_format($totalPriceSum, 2); ?></td>
                        <td>
                            <form action="payment.php" method="POST">
                                <input type="hidden" name="final_price" value="<?php echo $totalPriceSum; ?>">
                                <button type="submit" name="place_order">Place Order</button>
                            </form>
                        </td>
                    </tr>
                </tfoot>
            </table>
        <?php endif; ?>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        function updateQuantity(serviceId, change) {
            var quantityInput = document.getElementById('quantity' + serviceId);
            var currentQuantity = parseInt(quantityInput.value);
            var newQuantity = currentQuantity + change;
            if (newQuantity >= 1) {
                quantityInput.value = newQuantity;
                // Send AJAX request to update quantity in the database
                $.ajax({
                    type: 'POST',
                    url: 'update_quantity.php',
                    data: { service_id: serviceId, quantity: newQuantity },
                    dataType: 'json',
                    success: function(response) {
                        console.log(response);
                        if (response.success) {
                            console.log('Quantity updated successfully');
                        } else {
                            console.error('Error updating quantity:', response.error);
                        }
                        window.location.reload();
                    },
                    error: function(xhr, status, error) {
                        console.error('Error updating quantity:', error);
                    }
                });
            }
        }
    </script>
</body>
</html>
