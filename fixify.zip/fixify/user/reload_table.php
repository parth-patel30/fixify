<?php
include("db_connection.php");

// Fetch all requests by the user with role_id = 1
$sql_select = "SELECT request_id, title, description, status FROM requests WHERE userid = ? ORDER BY request_id DESC";
$stmt_select = $conn->prepare($sql_select);
$stmt_select->bind_param("i", $_SESSION['user_id']);
$stmt_select->execute();
$result = $stmt_select->get_result();

// Build the table HTML content
$tableHTML = '<table class="table table-bordered">';
$tableHTML .= '<thead>';
$tableHTML .= '<tr>';
$tableHTML .= '<th>Title</th>';
$tableHTML .= '<th>Description</th>';
$tableHTML .= '<th>Status</th>';
$tableHTML .= '<th>Action</th>';
$tableHTML .= '</tr>';
$tableHTML .= '</thead>';
$tableHTML .= '<tbody>';
while ($row = $result->fetch_assoc()) {
    $tableHTML .= '<tr>';
    $tableHTML .= '<td>' . htmlspecialchars($row['title']) . '</td>';
    $tableHTML .= '<td>' . htmlspecialchars($row['description']) . '</td>';
    $tableHTML .= '<td>' . htmlspecialchars($row['status']) . '</td>';
    $tableHTML .= '<td>';
    $tableHTML .= '<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#editModal' . $row['request_id'] . '">Edit</button>';
    $tableHTML .= '<button type="button" class="btn btn-danger" data-toggle="modal" data-target="#deleteModal' . $row['request_id'] . '">Delete</button>';
    $tableHTML .= '</td>';
    $tableHTML .= '</tr>';
}
$tableHTML .= '</tbody>';
$tableHTML .= '</table>';

// Close the prepared statement and database connection
$stmt_select->close();
$conn->close();

// Return the table HTML content as the response
echo $tableHTML;
?>
<script>
$(document).ready(function() {
    // Function to fetch and reload the table content
    function reloadTable() {
        $.ajax({
            url: 'reload_table.php',
            type: 'GET',
            success: function(response) {
                $('#tableContainer').html(response);
            },
            error: function(xhr, status, error) {
                console.log('Error fetching table content:', error);
            }
        });
    }

    // Call reloadTable() initially
    reloadTable();

    // Set interval to call reloadTable() every second (1000 ms)
    setInterval(reloadTable, 1000);
});
</script>
