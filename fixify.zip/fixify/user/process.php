<?php
session_start();
include("db_connection.php");

// Check if user is logged in and has admin access (role_id = 1)
if (!isset($_SESSION['user_id']) || $_SESSION['role_id'] !== 1) {
    header("Location: ../index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'add') {
            // Collect form data
            $title = $_POST['title'];
            $description = $_POST['description'];
            $status = isset($_POST['status']) ? $_POST['status'] : 0; // Default status is 0 if not provided

            // Prepare the SQL statement for insertion
            $sql_insert = "INSERT INTO requests (userid, title, description, status) VALUES (?, ?, ?, ?)";
            $stmt_insert = $conn->prepare($sql_insert);
            $stmt_insert->bind_param("isss", $_SESSION['user_id'], $title, $description, $status);

            // Execute the prepared statement for adding a new request
            if ($stmt_insert->execute()) {
                echo "Request inserted successfully.";
            } else {
                echo "Error inserting request. Please try again.";
            }

            // Close the prepared statement
            $stmt_insert->close();
        } elseif ($_POST['action'] == 'edit') {
            // Collect form data
            $request_id = $_POST['request_id'];
            $title = $_POST['title'];
            $description = $_POST['description'];
            $status = isset($_POST['status']) ? $_POST['status'] : 0; // Default status is 0 if not provided

            // Prepare the SQL statement for updating
            $sql_update = "UPDATE requests SET title = ?, description = ?, status = ? WHERE request_id = ?";
            $stmt_update = $conn->prepare($sql_update);
            $stmt_update->bind_param("ssii", $title, $description, $status, $request_id);

            // Execute the prepared statement for updating request
            if ($stmt_update->execute()) {
                echo "Request updated successfully.";
            } else {
                echo "Error updating request.";
            }

            // Close the prepared statement
            $stmt_update->close();
        } elseif ($_POST['action'] == 'delete') {
            // Collect form data
            $request_id = $_POST['request_id'];

            // Prepare the SQL statement for deletion
            $sql_delete = "DELETE FROM requests WHERE request_id = ?";
            $stmt_delete = $conn->prepare($sql_delete);
            $stmt_delete->bind_param("i", $request_id);

            // Execute the prepared statement for deleting request
            if ($stmt_delete->execute()) {
                echo "Request deleted successfully.";
            } else {
                echo "Error deleting request.";
            }

            // Close the prepared statement
            $stmt_delete->close();
        }
    }
}

// Close the database connection
$conn->close();
?>
