<?php
require('config.php');

?>

<form action="submit.php" method="post">
<script src="https://checkout.stripe.com/checkout.js" class="stripe-button" data-key="<?php echo $publishlekey ?>">
	data-amount="500"
	data-name="Fixify"
	data-description="Payment for services"
	data-image=""
	data-currency="inr"

</script>


</form>