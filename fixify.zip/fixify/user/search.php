<?php
include 'home.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit; // Add an exit statement after header redirection
}

// Establish database connection
$con = mysqli_connect("localhost", "root", "", "fixify");

// Check if the connection was successful
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch services based on search or status 1
$searchQueryPart = '';
if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $searchQueryPart = "WHERE s.servicename LIKE '%$search%'";
} else {
    $searchQueryPart = "WHERE s.status = 1";
}

// Fetch and display services
$query = "SELECT s.*, AVG(r.rating) AS avg_rating, COUNT(r.feedback) AS total_feedback 
          FROM services s
          LEFT JOIN ratings r ON s.serviceid = r.service_id
          $searchQueryPart
          GROUP BY s.serviceid";
$result = mysqli_query($con, $query);

// Fetch services into an array
$services = [];
while ($row = mysqli_fetch_assoc($result)) {
    $services[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <style>
        /* Adjust modal width */
        .modal-dialog {
            max-width: 800px;
            text-align: justify;
        }

        /* Ensure image fits within modal */
        .modal-body {
            display: flex;
        }

        .modal-body img {
            max-width: 250px;
            height: 250px;
            margin-right: 20px; /* Add margin to separate image from details */
        }

        .details {
            flex-grow: 1; /* Allow details to take remaining space */
        }

        /* Add padding to details for better spacing */
        .details p {
            padding-bottom: 10px;
        }

        .card-body:hover {
            box-shadow: 32px 32px 63px #797979, -32px -32px 63px #ffffff;
        }

        /* Webkit scrollbar */
        ::-webkit-scrollbar {
            width: 10px;
        }

        /* Track */
        ::-webkit-scrollbar-track {
            background: lightgrey; /* Dark background color */
        }

        /* Handle */
        ::-webkit-scrollbar-thumb {
            background: #343a40; /* Light color for the scrollbar handle */
            border-radius: 20px; /* Rounded corners */
        }

        /* Handle on hover */
        ::-webkit-scrollbar-thumb:hover {
            background: black; /* Darker color on hover */
        }
    </style>
</head>
<body>
    <h1 class="text-center">Services</h1>
    <div class="container mt-5">
        <?php if (isset($_GET['search'])): ?>
            <h3 class="text-center">Search Results for "<?php echo htmlspecialchars($_GET['search']); ?>"</h3>
        <?php endif; ?>
        <?php if (count($services) > 0): ?>
            <?php
            // Divide services into groups of three
            $chunks = array_chunk($services, 3);
            
            // Loop through each group
            foreach ($chunks as $group): ?>
            <div class="row">
                <?php foreach ($group as $service): ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card h-100 clickable-card" onclick="showServiceDetails('<?php echo $service['serviceid']; ?>')">
                        <?php if (!empty($service['image'])): ?>
                        <img src="../partner/<?php echo $service['image']; ?>" class="card-img-top" alt="Service Image">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $service['servicename']; ?></h5>
                            <p class="card-text">Price: &#8377;<?php echo $service['price']; ?></p>
                            <p class="card-text">Average Rating: <?php echo isset($service['avg_rating']) ? $service['avg_rating'] : 'N/A'; ?></p>
                            <p class="card-text">Total Feedback: <?php echo isset($service['total_feedback']) ? $service['total_feedback'] : 'N/A'; ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No results found.</p>
        <?php endif; ?>
    </div>

    <!-- Modal code here -->
    <?php foreach ($services as $service): ?>
    <div class="modal fade" id="serviceModal<?php echo $service['serviceid']; ?>" tabindex="-1" role="dialog" aria-labelledby="serviceModalLabel<?php echo $service['serviceid']; ?>" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="serviceModalLabel<?php echo $service['serviceid']; ?>"><?php echo $service['servicename']; ?> Details</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img src="../partner/<?php echo $service['image']; ?>" class="img-fluid mb-3" alt="Service Image">
                    <div class="details">
                        <p><b>Description:</b> <?php echo $service['description']; ?></p>
                        <p><b>Price:</b> &#8377;<?php echo $service['price']; ?></p>
                        <p><b>Average Rating:</b> <?php echo isset($service['avg_rating']) ? $service['avg_rating'] : 'N/A'; ?></p>
                        <!-- Display feedback here -->
                        <?php
                        // Fetch feedback from database for this service
                        $feedbackQuery = "SELECT feedback FROM ratings WHERE service_id = " . $service['serviceid'];
                        $feedbackResult = mysqli_query($con, $feedbackQuery);
                        if (mysqli_num_rows($feedbackResult) > 0) {
                            echo "<p><b>Feedback:</b></p>";
                            
                            while ($row = mysqli_fetch_assoc($feedbackResult)) {
                                echo "<b>-></b>" . $row['feedback'] . "";
                            }
                            
                        } else {
                            echo "<p>No Feedback</p>";
                        }
                        ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <form method="POST" action="add_to_cart.php">
                        <input type="hidden" name="service_id" value="<?php echo $service['serviceid']; ?>">
                        <button type="submit" class="btn btn-primary">Add to Cart</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

    <!-- Bootstrap JS and jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        // JavaScript function to show service details modal
        function showServiceDetails(serviceId) {
            $('#serviceModal' + serviceId).modal('show');
        }
    </script>
</body>
</html>
