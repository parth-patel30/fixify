<?php
require('stripe-php-master/init.php');

$publishlekey='pk_test_51P5OvvSCXKXhIpVgSAoXhgkuNXmGN5GXHY9rw556JHSc1VjP1E9VRAPWLL9KpNgUUYwks35lofEU9qnZ7kvcvbQc00eCRlwCo0';




$secretkey="
sk_test_51P5OvvSCXKXhIpVgPi3VH12EDZCZgtjhnLrnk2fJqLUqaYEeNq30oBQ20GvC5JUkoI91DzltGEryO4g3yMWK2jFS009SAYhR8D";



\Stripe\Stripe::setApiKey($secretkey);

// Create a Checkout Session
$session = \Stripe\Checkout\Session::create([
    'payment_method_types' => ['card'],
    'line_items' => [
        [
            'price_data' => [
                'currency' => 'usd',
                'product_data' => [
                    'name' => 'Service Name', // Replace with your service name
                ],
                'unit_amount' => 500, // Amount in cents (e.g., $5.00)
            ],
            'quantity' => 1,
        ],
    ],
    'mode' => 'payment',
    'success_url' => 'https://yourdomain.com/success', // Redirect URL after successful payment
    'cancel_url' => 'https://yourdomain.com/cancel', // Redirect URL if payment is canceled
]);

header('Content-Type: application/json');
echo json_encode(['id' => $session->id]); // Return the session ID to the client
?>
