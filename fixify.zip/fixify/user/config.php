<?php
require('stripe-php-master/init.php');

$publishlekey='pk_test_51P5OvvSCXKXhIpVgSAoXhgkuNXmGN5GXHY9rw556JHSc1VjP1E9VRAPWLL9KpNgUUYwks35lofEU9qnZ7kvcvbQc00eCRlwCo0';




$secretkey="
sk_test_51P5OvvSCXKXhIpVgPi3VH12EDZCZgtjhnLrnk2fJqLUqaYEeNq30oBQ20GvC5JUkoI91DzltGEryO4g3yMWK2jFS009SAYhR8D";



\Stripe\Stripe::setApiKey($secretkey);
?>