<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$con = mysqli_connect("localhost", "root", "", "fixify");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$userId = $_SESSION['user_id'];

// Retrieve form data
$userAddress = mysqli_real_escape_string($con, $_POST['address']);
$selectedDate = mysqli_real_escape_string($con, $_POST['date']);
$selectedTime = mysqli_real_escape_string($con, $_POST['time']);
$paymentMode = 'By Card';
$paymentstatus = 'successfully';

// Fetch service ids and quantities from the cart
$sql = "SELECT serviceid, quantity, total_price FROM cart WHERE id = $userId";
$result = $con->query($sql);
$servicesData = []; // Initialize an empty array to store service IDs and quantities

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $servicesData[] = $row; // Store service IDs and quantities in the array
    }
}

// Check if servicesData is not empty
if (empty($servicesData)) {
    echo "Error: No services found in the cart.";
    exit();
}

$sql = "INSERT INTO orders (serviceid, userid, address, select_date, select_time, quantity, total_price, paymentmode, paymentstatus, status, order_date)  VALUES (?, ?, ?, ?, ?, ?, ?, 'By Card', ?, '0', NOW())";
$stmt = mysqli_prepare($con, $sql);

if ($stmt) {
    foreach ($servicesData as $serviceData) {
        $serviceId = (int) $serviceData['serviceid'];
        $quantity = (int) $serviceData['quantity'];
        $total_price = (int) $serviceData['total_price'];

        // Update the type definition string to match the order of placeholders in the SQL query
       mysqli_stmt_bind_param($stmt, "iissssis", $serviceId, $userId, $userAddress, $selectedDate, $selectedTime, $quantity, $total_price,$paymentstatus);



        mysqli_stmt_execute($stmt);

         $notificationMsg = 'New order placed successfully';
        $notificationSql = "INSERT INTO notifications (user_id, message) VALUES (?, ?)";
        $notificationStmt = mysqli_prepare($con, $notificationSql);

        if ($notificationStmt) {
            mysqli_stmt_bind_param($notificationStmt, "is", $userId, $notificationMsg);
            mysqli_stmt_execute($notificationStmt);
            mysqli_stmt_close($notificationStmt);
        } else {
            echo "Error adding notification: " . mysqli_error($con);
        }
    }

    mysqli_stmt_close($stmt);
   echo '<script>alert("Order placed successfully.");</script>';
   header("Location: ../user/order.php");
} else {
    echo "Error: " . mysqli_error($con);
}

mysqli_close($con);
?>
