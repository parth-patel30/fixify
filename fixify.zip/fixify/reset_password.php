<?php
session_start();

// Define the generateRandomOtp function
function generateRandomOtp() {
    return strval(rand(100000, 999999));
}

// Database connection code goes here
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fixify";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $email = $_POST["email"];

    // Check if email exists in the database
    $checkEmailQuery = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($checkEmailQuery);

    if ($result->num_rows > 0) {
        // Email exists in the database, redirect or show an alert message
        $_SESSION['email_exists'] = true;
        header("Location: login.php"); // Redirect to login page
        exit;
    }

    // Email doesn't exist, proceed with generating OTP and sending email
    $otp = generateRandomOtp();
    $_SESSION['otp'] = $otp;

    // Call the sendOtpToEmail function
    if (sendOtpToEmail($email, $otp)) {
        header("Location: verify_passotp.php");
        exit;
    } else {
        echo "Failed to send OTP. Please try again.";
    }
}

$conn->close(); // Close database connection

function sendOtpToEmail($email, $otp) {
     $apiKey = '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';

    $url = "https://api.sendinblue.com/v3/smtp/email";

    $message = "<pre> 
    Dear <b>$username</b>,

    Welcome to you the fixify, 
    for reset Account password  
    OTP is:  <b>$otp</b>
    </pre>";

    $htmlContent = "<html><body><p>$message</p></body></html>";

    $data = [
        'subject' => 'Reset Password',
        'sender' => ['name' => 'Fixify', 'email' => 'fixify@email.com'],
        'to' => [['email' => $email, 'name' => $username]],
        'params' => ['otp' => $otp, 'message' => $message],
        'htmlContent' => $htmlContent,
        'textContent' => $message,
    ];

    $ch = curl_init($url);

    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'api-key: ' . $apiKey,
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo 'Curl error: ' . curl_error($ch);
        return false;
    }

    curl_close($ch);

    $jsonResponse = json_decode($response, true);
    if ($jsonResponse && isset($jsonResponse['messageId'])) {
        return true;
    } else {
        echo 'Failed to send email. Sendinblue response: ' . $response;
        return false;
    }
}
?>
