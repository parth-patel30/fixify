<?php
session_start();
include("db_connection.php");

// Check if user is logged in and has admin access (role_id = 1)
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

// Check if the request ID is provided in the URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "Error: Request ID not provided.";
    exit();
}

$request_id = $_GET['id'];

// Fetch the request data from the database
$sql_select = "SELECT title, description, status FROM requests WHERE request_id = ?";
$stmt_select = $conn->prepare($sql_select);
$stmt_select->bind_param("i", $request_id);
$stmt_select->execute();
$result = $stmt_select->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $title = $row['title'];
    $description = $row['description'];
    $status = $row['status'];
} else {
    echo "Error: Request not found.";
    exit();
}

// Check if form is submitted for editing request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_request'])) {
    // Collect form data
    $new_title = $_POST['title'];
    $new_description = $_POST['description'];
    $new_status = $_POST['status'];

    // Update the request data in the database
    $sql_update = "UPDATE requests SET title = ?, description = ?, status = ? WHERE request_id = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("ssii", $new_title, $new_description, $new_status, $request_id);

    if ($stmt_update->execute()) {
        echo '<div class="alert alert-success" role="alert">Request updated successfully.</div>';
        // Redirect back to main requests page or display success message
        header("Refresh: 2; URL=main_requests_page.php");
    } else {
        echo '<div class="alert alert-danger" role="alert">Error updating request.</div>';
    }

    // Close the prepared statement
    $stmt_update->close();
}

// Close the prepared statement for selecting request
$stmt_select->close();

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Request</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-3">
    <h1>Edit Request</h1>
    <form id="editRequestForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>?id=<?php echo $request_id; ?>" method="POST">
        <div class="form-group">
            <label for="title">Title:</label>
            <input type="text" id="title" name="title" class="form-control" value="<?php echo htmlspecialchars($title); ?>" required>
        </div>
        <div class="form-group">
            <label for="description">Description:</label>
            <textarea id="description" name="description" rows="4" class="form-control" required><?php echo htmlspecialchars($description); ?></textarea>
        </div>
        
        <button type="submit" name="edit_request" class="btn btn-primary">Save Changes</button>
    </form>
</div>
</body>
</html>
