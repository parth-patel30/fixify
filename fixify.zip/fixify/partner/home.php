<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fixify";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Fetch user status
    $statusQuery = "SELECT status FROM users WHERE id = $user_id";
    $statusResult = $conn->query($statusQuery);

    if ($statusResult->num_rows > 0) {
        $statusRow = $statusResult->fetch_assoc();
        $status = $statusRow['status'];
    }

    // Fetch user availability
    $availableQuery = "SELECT available FROM users WHERE id = $user_id";
    $availableResult = $conn->query($availableQuery);

    if ($availableResult->num_rows > 0) {
        $availableRow = $availableResult->fetch_assoc();
        $available = $availableRow['available'];
    }

    // Fetch notifications
    $sql = "SELECT * FROM notifications";
    $result = $conn->query($sql);

    // Check if the query was successful
    if ($result === false) {
        echo "Error fetching notifications: " . $conn->error;
    }
} else {
    header("Location: ../index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

     <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Fixify</title>
  <link rel="icon" type="image/x-icon" href="fixify12.png">
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
    .sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #343a40;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
    margin-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}
.custom-icon path {
    
    fill: white; 
}
.slidenav{
    font-size:30px;
    cursor:pointer;
    margin-left: 1%;
}
.slidenav:hover{
    
    border-radius: 10px;
    background-color:   #EAEBEC;
}
.cart-logo {
    position: relative;
   
  
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;
   font-size: 10px;
   height: 10px;
    font-weight: bold;
  }

  .cart-logo span {
    position: absolute;
    top: -10px;
    right: -10px;
    width: 20px;
    height: 20px;
    background-color: grey;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;
    font-size: 14px;
    font-weight: bold;
  }
  
     </style>
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Navigation Bar -->
<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <a class="navbar-brand" href="index.php"><div style="font-size: 30px;text-shadow: 2px 2px 4px white;">Fixify</div></a>
    <ul class="navbar-nav ml-auto">
        <li class="nav-item">
            <span class="navbar-text mr-3">
                <?php
                if (isset($status)) {
                    if ($status == 0) {
                        echo "<span class='text-danger'>Status: Pending</span>";
                    } elseif ($status == 1) {
                        echo "<span class='text-success'>Status: Activated</span>";
                    } else {
                        echo "<span class='text-muted'>Status: Unknown</span>";
                    }
                } else {
                    echo "<span class='text-danger'>User not found</span>";
                }
                ?>
            </span>
            <span class="navbar-text">
                <?php
                if (isset($available)) {
                    if ($available == 0) {
                        echo "<span class='text-danger'>Availability: No</span>";
                    } elseif ($available == 1) {
                        echo "<span class='text-success'>Availability: Yes</span>";
                    } else {
                        echo "<span class='text-muted'>Availability: Unknown</span>";
                    }
                } else {
                    echo "<span class='text-danger'>User not found</span>";
                }
                ?>
            </span>&nbsp;&nbsp;&nbsp;&nbsp;
        </li>
        <li class="nav-item" style="padding-top:5px;">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" class="bi bi-bell custom-icon" viewBox="0 0 16 16" data-toggle="modal" data-target="#notificationModal">
                <path fill="#000" d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2M8 1.918l-.797.161A4 4 0 0 0 4 6c0 .628-.134 2.197-.459 3.742-.16.767-.376 1.566-.663 2.258h10.244c-.287-.692-.502-1.49-.663-2.258C12.134 8.197 12 6.628 12 6a4 4 0 0 0-3.203-3.92zM14.22 12c.223.447.481.801.78 1H1c.299-.199.557-.553.78-1C2.68 10.2 3 6.88 3 6c0-2.42 1.72-4.44 4.005-4.901a1 1 0 1 1 1.99 0A5 5 0 0 1 13 6c0 .88.32 4.2 1.22 6"/>
            </svg>
        </li>
    </ul>
</nav>

    <!-- Modal -->
    <div class="modal fade" id="notificationModal" tabindex="-1" role="dialog" aria-labelledby="notificationModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="notificationModalLabel">Notifications</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Content loaded via PHP -->
                    <?php
                    if ($result === false) {
    echo "Error fetching notifications: " . $conn->error;
} else {
    // Check if notifications were found
    if ($result->num_rows > 0) {
        // Notifications found, display them
        while ($row = $result->fetch_assoc()) {
            echo "<div class='notification-item'>" . $row['message'] . " - " . $row['created_at'] . "</div>";
        }
    } else {
        // No notifications found
        echo "No notifications found.";
    }
}
                    ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Side Navigation -->
    <div id="mySidenav" class="sidenav">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <a href="profile.php">My Profile</a>
        <a href="addservices.php">Add Services</a>
        <a href="manageservices.php">Manage Services</a>
        <a href="manageorder.php">Manage Order</a>
        <a href="addrequest.php">Add Request</a>
        <a href="../index.php">Logout</a>
    </div>

    <!-- Use any element to open the sidenav -->
    <span class="slidenav" onclick="openNav()">&#9776;</span>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
         <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#notificationModal').on('show.bs.modal', function() {
                $.ajax({
                    url: 'fetch_notifications.php',
                    type: 'GET',
                    success: function(response) {
                        $('#notification-item').html(response);
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });
        });
          
        function openNav() {
            document.getElementById("mySidenav").style.width = "250px";
        }

        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
        }
    </script>
</body>
</html>
