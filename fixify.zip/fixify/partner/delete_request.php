<?php
session_start();
include("db_connection.php");

// Check if user is logged in and has admin access (role_id = 1)
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

// Check if the request ID is provided in the URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "Error: Request ID not provided.";
    exit();
}

$request_id = $_GET['id'];

// Check if form is submitted for deleting request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_request'])) {
    // Delete the request from the database
    $sql_delete = "DELETE FROM requests WHERE request_id = ?";
    $stmt_delete = $conn->prepare($sql_delete);
    $stmt_delete->bind_param("i", $request_id);

    if ($stmt_delete->execute()) {
        echo '<div class="alert alert-success" role="alert">Request deleted successfully.</div>';
        // Redirect back to main requests page or display success message
        header("Refresh: 2; URL=main_requests_page.php");
    } else {
        echo '<div class="alert alert-danger" role="alert">Error deleting request.</div>';
    }

    // Close the prepared statement
    $stmt_delete->close();
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Delete Request</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-3">
    <h1>Delete Request</h1>
    <form id="deleteRequestForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>?id=<?php echo $request_id; ?>" method="POST">
        <p>Are you sure you want to delete this request?</p>
        <button type="submit" name="delete_request" class="btn btn-danger">Delete</button>
        <a href="main_requests_page.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>
