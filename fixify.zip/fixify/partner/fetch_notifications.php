<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fixify";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all notifications from the database
$sql = "SELECT * FROM notifications ORDER BY created_at DESC LIMIT 10"; // Limit to 10 notifications, change as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output notifications
    while ($row = $result->fetch_assoc()) {
        echo "<div class='notification-item'>" . $row['message'] . " - " . $row['created_at'] . "</div>";
    }
} else {
    echo "No notifications found.";
}

// Close the database connection
$conn->close();
?>
