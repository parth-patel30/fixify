<?php
include("home.php");
$con = mysqli_connect("localhost", "root", "", "fixify");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['Updated'])) {
        $edit_id = $_POST['id'];
        $new_username = $_POST['new_username'];
        $new_email = $_POST['new_email'];
        $new_phoneno = $_POST['new_phoneno'];
        $new_address = $_POST['new_address'];

        $update_query = "UPDATE users SET username='$new_username', email='$new_email', 
                         phoneno='$new_phoneno', address='$new_address'
                         WHERE id='$edit_id'";
        
        if ($con->query($update_query) === TRUE) {
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    Record updated successfully!
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>';
        } else {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Error updating record: ' . $con->error . '
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>';
        }
    }
}

$user_id = $_SESSION['user_id']; // Assuming the user ID is stored in the session
$sql = "SELECT * FROM users WHERE id = $user_id";
$result = $con->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            margin-top: 50px;
        }
        .profile-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .profile-card h3 {
            margin-bottom: 10px;
        }
        .modal-footer .btn {
            background-color: #343a40;
            color: #fff;
        }
        .modal-footer .btn-secondary {
            background-color: #6c757d;
        }
        .alert-message {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mb-4">Profile</h1>
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="row profile-card">
                    <div class="col-md-8">
                        <h3><?php echo $row['username']; ?></h3>
                        <p><strong>Email:</strong> <?php echo $row['email']; ?></p>
                        <p><strong>Phone No.:</strong> <?php echo $row['phoneno']; ?></p>
                        <p><strong>Address:</strong> <?php echo $row['address']; ?></p>
                    </div>
                    <div class="col-md-4 text-right">
                        <button type="button" class="btn btn-info" data-toggle="modal" data-target="#editModal<?php echo $row['id']; ?>">Edit Profile</button>
                    </div>
                </div>

                <!-- Edit Modal -->
                <div class="modal fade" id="editModal<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editModalLabel">Edit Profile</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form method="post">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                    <div class="form-group">
                                        <label for="new_username">Username:</label>
                                        <input type="text" class="form-control" id="new_username" name="new_username" value="<?php echo $row['username']; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="new_email">Email:</label>
                                        <input type="email" class="form-control" id="new_email" name="new_email" value="<?php echo $row['email']; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="new_phoneno">Phone No.:</label>
                                        <input type="text" class="form-control" id="new_phoneno" name="new_phoneno" value="<?php echo $row['phoneno']; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="new_address">Address:</label>
                                        <textarea class="form-control" id="new_address" name="new_address"><?php echo $row['address']; ?></textarea>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary" name="Updated">Update</button>
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No users found.</p>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS and jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
