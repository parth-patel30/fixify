<?php
// Include necessary files and initialize database connection if needed
include 'home.php';

// Fetch all requests by the user with role_id = 1
$sql_select = "SELECT request_id, title, description, status FROM requests WHERE userid = ? ORDER BY request_id DESC";
$stmt_select = $conn->prepare($sql_select);
$stmt_select->bind_param("i", $_SESSION['user_id']);
$stmt_select->execute();
$result = $stmt_select->get_result();

// Generate HTML for the table
$output = '<table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>';
while ($row = $result->fetch_assoc()) {
    $output .= '<tr>
                    <td>' . htmlspecialchars($row['title']) . '</td>
                    <td>' . htmlspecialchars($row['description']) . '</td>
                    <td>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#editModal' . $row['request_id'] . '">Edit</button>
                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#deleteModal' . $row['request_id'] . '">Delete</button>
                    </td>
                </tr>';
}
$output .= '</tbody></table>';

// Close prepared statement and database connection
$stmt_select->close();
$conn->close();

// Output the generated HTML
echo $output;
?>
