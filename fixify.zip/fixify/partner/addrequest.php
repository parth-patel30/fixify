<?php
include 'home.php';

// Check if user is logged in and has admin access (role_id = 1)
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

// Initialize variables
$result = null;
$successMsg = $errorMsg = '';

// Check if the form is submitted for adding a new request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    // Collect form data
    $title = $_POST['title'];
    $description = $_POST['description'];
    $status = isset($_POST['status']) ? $_POST['status'] : 0; // Default status is 0 if not provided
    $roleid = '2';

    // Prepare the SQL statement for insertion
    $sql_insert = "INSERT INTO requests (userid, roleid ,title, description, status) VALUES (?, ?, ?, ?, ?)";
    $stmt_insert = $conn->prepare($sql_insert);
    $stmt_insert->bind_param("iisss", $_SESSION['user_id'], $roleid, $title, $description, $status);

    // Execute the prepared statement for adding a new request
    if ($stmt_insert->execute()) {
        $successMsg = 'Request inserted successfully.';
    } else {
        $errorMsg = 'Error inserting request. Please try again.';
    }

    // Close the prepared statement
    $stmt_insert->close();
}

// Check if edit button is clicked
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_request'])) {
    $edit_id = $_POST['edit_id'];
    $edit_title = $_POST['edit_title'];
    $edit_description = $_POST['edit_description'];
    $edit_status = '0';

    $sql_update = "UPDATE requests SET title = ?, description = ?, status = ? WHERE request_id = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("ssii", $edit_title, $edit_description, $edit_status, $edit_id);

    if ($stmt_update->execute()) {
        $successMsg = 'Request updated successfully.';
    } else {
        $errorMsg = 'Error updating request.';
    }

    // Close the prepared statement for updating request
    $stmt_update->close();
}

// Check if delete button is clicked
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_request'])) {
    $delete_id = $_POST['delete_id'];

    // Delete the request from the database
    $sql_delete = "DELETE FROM requests WHERE request_id = ?";
    $stmt_delete = $conn->prepare($sql_delete);
    $stmt_delete->bind_param("i", $delete_id);

    if ($stmt_delete->execute()) {
        $successMsg = 'Request deleted successfully.';
    } else {
        $errorMsg = 'Error deleting request.';
    }

    // Close the prepared statement for deleting request
    $stmt_delete->close();
}

// Fetch all requests by the user with userid after any modifications
$sql_select = "SELECT request_id, title, description, status FROM requests WHERE userid = ? ORDER BY request_id DESC";
$stmt_select = $conn->prepare($sql_select);
$stmt_select->bind_param("i", $_SESSION['user_id']);
$stmt_select->execute();
$result = $stmt_select->get_result();

?>



<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Requests Management</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
   <div class="container mt-3">
    <?php if (!empty($successMsg)) : ?>
        <div id="successMsg" class="alert alert-success" role="alert">
            <?php echo $successMsg; ?>
        </div>
    <?php endif; ?>
    <?php if (!empty($errorMsg)) : ?>
        <div id="errorMsg" class="alert alert-danger" role="alert">
            <?php echo $errorMsg; ?>
        </div>
    <?php endif; ?>
<div class="container mt-3">
    <h1 class="mb-4">Requests Management</h1>
    <button type="button" class="btn btn-primary mb-3" data-toggle="modal" data-target="#addRequestModal">Add New Request</button>

    <!-- Add New Request Modal -->
    <div class="modal fade" id="addRequestModal"  tabindex="-1" role="dialog" aria-labelledby="addRequestModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addRequestModalLabel">Add New Request</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="addRequestForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                        <div class="form-group">
                            <label for="title">Title:</label>
                            <input type="text" id="title" name="title" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="description">Description:</label>
                            <textarea id="description" name="description" rows="4" class="form-control" required></textarea>
                        </div>
                        <div class="form-group">
                            <input type="hidden" id="status" name="status" value="0">
                        </div>
                        <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Request Modal -->
    <div class="modal fade" id="editRequestModal" tabindex="-1" role="dialog" aria-labelledby="editRequestModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editRequestModalLabel">Edit Request</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="editRequestForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                        <input type="hidden" id="edit_id" name="edit_id">
                        <div class="form-group">
                            <label for="edit_title">Title:</label>
                            <input type="text" id="edit_title" name="edit_title" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="edit_description">Description:</label>
                                                    <textarea id="edit_description" name="edit_description" rows="4" class="form-control" required></textarea>
                        </div>
                        <div class="form-group">
                            <label for="edit_status">Status:</label>
                            <input type="text" id="edit_status" name="edit_status" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary" name="edit_request">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Request Modal -->
    <div class="modal fade" id="deleteRequestModal" tabindex="-1" role="dialog" aria-labelledby="deleteRequestModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteRequestModalLabel">Confirm Delete</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this request?</p>
                </div>
                <div class="modal-footer">
                    <form id="deleteRequestForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                        <input type="hidden" id="delete_id" name="delete_id">
                        <button type="submit" class="btn btn-danger" name="delete_request">Delete</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Display Requests Table -->
    <h2 class="mt-5 mb-3">My Requests</h2>
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                        <td><?php echo htmlspecialchars($row['description']); ?></td>
                        
                        <td>
                            <!-- Edit Button -->
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#editRequestModal<?php echo $row['request_id']; ?>">Edit</button>
                            <!-- Delete Button -->
                            <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#deleteRequestModal<?php echo $row['request_id']; ?>">Delete</button>
                        </td>
                    </tr>

                    <!-- Edit Request Modal for each request -->
                    <div class="modal fade" id="editRequestModal<?php echo $row['request_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="editRequestModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editRequestModalLabel">Edit Request</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form id="editRequestForm<?php echo $row['request_id']; ?>" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                                        <input type="hidden" id="edit_id" name="edit_id" value="<?php echo $row['request_id']; ?>">
                                        <div class="form-group">
                                            <label for="edit_title">Title:</label>
                                            <input type="text" id="edit_title" name="edit_title" class="form-control" required value="<?php echo htmlspecialchars($row['title']); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="edit_description">Description:</label>
                                            <textarea id="edit_description" name="edit_description" rows="4" class="form-control" required><?php echo htmlspecialchars($row['description']); ?></textarea>
                                        </div>
                                       
                                        <button type="submit" class="btn btn-primary" name="edit_request">Save Changes</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Delete Request Modal for each request -->
                    <div class="modal fade" id="deleteRequestModal<?php echo $row['request_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="deleteRequestModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="deleteRequestModalLabel">Confirm Delete</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <p>Are you sure you want to delete this request?</p>
                                </div>
                                <div class="modal-footer">
                                    <form id="deleteRequestForm<?php echo $row['request_id']; ?>" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                                        <input type="hidden" id="delete_id" name="delete_id" value="<?php echo $row['request_id']; ?>">
                                        <button type="submit" class="btn btn-danger" name="delete_request">Delete</button>
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    // Function to hide messages after 2 seconds
    setTimeout(function() {
        document.getElementById('successMsg').style.display = 'none';
        document.getElementById('errorMsg').style.display = 'none';
    }, 2000); // 2000 milliseconds = 2 seconds
</script>
</body>
</html>

