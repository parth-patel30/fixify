<?php
include("home.php");
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fixify"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle status update if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['status_update'])) {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];

    $update_sql = "UPDATE orders SET status = '$status' WHERE order_id = $order_id";

    if ($conn->query($update_sql) === TRUE) {
        echo '<div class="alert alert-success">Status updated successfully.</div>';
    } else {
        echo '<div class="alert alert-danger">Error updating status: ' . $conn->error . '</div>';
    }
}

// SQL query to fetch data from the orders table and join with users and services tables
$sql = "SELECT o.order_id, o.serviceid, s.servicename, o.userid, u.username, u.phoneno, o.address, o.select_date, o.select_time, o.quantity, o.total_price, o.paymentmode, o.paymentstatus, o.status, o.order_date
        FROM orders o
        INNER JOIN users u ON o.userid = u.id
        INNER JOIN services s ON o.serviceid = s.serviceid
        ORDER BY o.order_date DESC"; 

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo '<div class="container mt-5">';
    echo '<h1 class="mb-4">Orders List</h1>';
    echo '<div class="table-responsive">';
    echo '<table class="table table-striped">';
    echo '<thead>';
    echo '<tr>';
    echo '<th>Order ID</th>';
    echo '<th>Service Name</th>'; 
    echo '<th>Username</th>'; // Added Username column
    echo '<th>Phone Number</th>'; // Added Phone Number column
    echo '<th>Address</th>';
    echo '<th>Select Date</th>';
    echo '<th>Select Time</th>';
    echo '<th>Quantity</th>';
    echo '<th>Total Price</th>';
    echo '<th>Payment Mode</th>';
    echo '<th>Payment Status</th>';
    echo '<th>Status</th>';
    echo '<th>Order Date</th>';
    echo '<th>Action</th>'; // Added Action column for status dropdown
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';$seri='1';
    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $seri . '</td>';
        echo '<td>' . $row["servicename"] . '</td>'; 
        echo '<td>' . $row["username"] . '</td>'; // Display username
        echo '<td>' . $row["phoneno"] . '</td>'; // Display phone number
        echo '<td>' . $row["address"] . '</td>';
        echo '<td>' . $row["select_date"] . '</td>';
        echo '<td>' . $row["select_time"] . '</td>';
        echo '<td>' . $row["quantity"] . '</td>';
        echo '<td>' . $row["total_price"] . '</td>';
        echo '<td>' . $row["paymentmode"] . '</td>';
        echo '<td>' . $row["paymentstatus"] . '</td>';
        echo '<td>' . ($row["status"] == 0 ? 'Pending' : 'Completed') . '</td>'; // Display status as text
        echo '<td>' . $row["order_date"] . '</td>';
        echo '<td>'; $seri++;
        echo '<form method="post" action="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '">';
        echo '<input type="hidden" name="order_id" value="' . $row["order_id"] . '">';
        echo '<select name="status" class="form-control">';
        echo '<option value="0" ' . ($row["status"] == 0 ? 'selected' : '') . '>Pending</option>';
        echo '<option value="1" ' . ($row["status"] == 1 ? 'selected' : '') . '>Completed</option>';
        echo '</select>';
        echo '<input type="submit" name="status_update" value="Update" class="btn btn-primary mt-2">';
        echo '</form>';
        echo '</td>';
        echo '</tr>';
    }
    echo '</tbody>';
    echo '</table>';
    echo '</div>'; // Close table-responsive div
    echo '</div>'; // Close container div
} else {
    echo '<div class="container mt-5">';
    echo '<h1 class="mb-4">Orders List</h1>';
    echo '<div class="alert alert-info">No data found in the table.</div>';
    echo '</div>'; // Close container div
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Orders List</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
</body>
</html>
