<?php
include "home.php";

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fixify";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
} else {
    header("Location: ../index.php");
    exit(); // Add an exit after redirection
}

// Fetch user status and availability in one query for efficiency
$userQuery = "SELECT status, available FROM users WHERE id = $user_id";
$userResult = $conn->query($userQuery);

if ($userResult->num_rows > 0) {
    $userRow = $userResult->fetch_assoc();
    $status = $userRow['status'];
    $available = $userRow['available'];
} else {
    echo "<div class='alert alert-danger' role='alert'>User not found.</div>";
    exit();
}

// Check if account is activated and available
if ($status == 0 || $available == 0) {
    echo "<div class='alert alert-warning text-center'>Please wait to activate your account.</div>";
    exit();
}

if (isset($_POST['servicename'], $_POST['price'])) {
    $servicename = mysqli_real_escape_string($conn, $_POST['servicename']);
    $description = isset($_POST['description']) ? mysqli_real_escape_string($conn, $_POST['description']) : '';
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    $ratings = "0";
    $reviews = "0";
    
    $target_dir = "img/serv/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);

    $sql = "INSERT INTO services (servicename, description, Image, Price, Ratings, reviews, userid)
            VALUES ('$servicename', '$description', '$target_file', '$price', '$ratings', '$reviews', '$user_id')";

    if ($conn->query($sql) === TRUE) {
        echo "<div class='alert alert-success' role='alert'>Service added successfully.</div>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Service</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Add New Service</h2>
        <form action="addservices.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="servicename">Service Name:</label>
                <input type="text" class="form-control" id="servicename" name="servicename" required>
            </div>
            <div class="form-group">
                <label for="description">Description:</label>
                <textarea class="form-control" id="description" name="description"></textarea>
            </div>
            <div class="form-group">
                <label for="image">Image:</label>
                <input type="file" class="form-control-file" id="image" name="image">
            </div>
            <div class="form-group">
                <label for="price">Price:</label>
                <input type="number" step="0.01" class="form-control" id="price" name="price" required>
            </div>
            <center><button type="submit" class="btn btn-primary">Add Service</button></center>
        </form>
    </div>
</body>
</html>
