<?php
include("home.php");
$con = mysqli_connect("localhost", "root", "", "fixify");

$sql = "SELECT * FROM users WHERE id = $user_id";
$result = $con->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $userId = $row['id'];
    $userName = $row['username'];
    $servicesId = $row['services_id'];

    // Check if the 'description' column exists in the 'users' table
    $description = isset($row['description']) ? $row['description'] : "N/A";

    $servicesQuery = "SELECT servicename, description, price FROM services WHERE userid = '$user_id'";
    $servicesResult = mysqli_query($con, $servicesQuery);
    if ($servicesResult && $servicesResult->num_rows > 0) {
        $services = array();
        while ($serviceRow = $servicesResult->fetch_assoc()) {
            $services[] = $serviceRow;
        }
    } else {
        $services = array();
    }
} else {
    $userId = "N/A";
    $userName = "N/A";
    $description = "N/A";
    $services = array();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Services</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            margin-top: 50px;
        }

        .card {
            margin-bottom: 20px;
            /* Set a fixed height for the card */
            height: 200px; /* Adjust as needed */
            overflow: hidden;
        }

        .card-body {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            /* Set height and overflow for card body content */
            height: 100%;
            overflow: hidden;
        }

        .card-title {
            /* Prevent text from wrapping and truncate with ellipsis */
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            margin-bottom: 10px;
        }

        .card-text {
            /* Prevent text from wrapping and truncate with ellipsis */
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            margin-bottom: 5px;
        }

        /* Optional: Adjust the font size for smaller screens */
        @media (max-width: 576px) {
            .card-title,
            .card-text {
                font-size: 14px; /* Example font size */
            }
        }
    </style>
</head>
<body> 
    <div class="container">
        <h1 class="mb-4">User Services</h1>
        <div class="row">
            <?php foreach ($services as $service): ?>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $service['servicename']; ?></h5>
                            <p class="card-text"><strong>Description:</strong> <?php echo $service['description']; ?></p>
                            <p class="card-text"><strong>Price:</strong> <?php echo $service['price']; ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Bootstrap JS and jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
