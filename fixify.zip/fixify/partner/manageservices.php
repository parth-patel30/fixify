<?php
include "home.php";

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fixify";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
} else {
    header("Location: ../index.php");
    exit(); // Add an exit after redirection
}

// Check if edit form is submitted
if (isset($_POST['edit_id'])) {
    $edit_id = $_POST['edit_id'];
    $sql = "SELECT * FROM services WHERE serviceid = '$edit_id' AND userid = '$user_id'";
    $result = $conn->query($sql);
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $edit_servicename = $row['servicename'];
        $edit_description = $row['description'];
        $edit_price = $row['price'];
        // Handle other fields as needed
    } else {
        echo "Service not found.";
        exit(); // Stop further execution
    }
}

// Process edit form submission
if (isset($_POST['update_service'])) {
    $edit_id = $_POST['edit_id'];
    $edit_servicename = mysqli_real_escape_string($conn, $_POST['edit_servicename']);
    $edit_description = isset($_POST['edit_description']) ? mysqli_real_escape_string($conn, $_POST['edit_description']) : '';
    $edit_price = mysqli_real_escape_string($conn, $_POST['edit_price']);
    // Handle other fields as needed

    // Update the service in the database
    $sql = "UPDATE services SET servicename='$edit_servicename', description='$edit_description', price='$edit_price' WHERE serviceid='$edit_id' AND userid='$user_id'";
  if ($conn->query($sql) === TRUE) {
    echo "<script>window.location.href = '{$_SERVER['PHP_SELF']}';</script>";
    exit();
} else {
    echo "Error updating service: " . $conn->error;
}

}

// Process delete request
if (isset($_POST['delete_service'])) {
    $delete_id = $_POST['delete_id'];
    $sql = "DELETE FROM services WHERE serviceid='$delete_id' AND userid='$user_id'";
    if ($conn->query($sql) === TRUE) {
        header("Location: {$_SERVER['PHP_SELF']}");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit/Delete Service</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-1">
        <h2>Edit/Delete Service</h2>

        <!-- Edit Modal -->
        <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form action="" method="POST">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editModalLabel">Edit Service</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="edit_id" id="edit_id">
                            <div class="form-group">
                                <label for="edit_servicename">Service Name:</label>
                                <input type="text" class="form-control" id="edit_servicename" name="edit_servicename" required>
                            </div>
                            <div class="form-group">
                                <label for="edit_description">Description:</label>
                                <textarea class="form-control" id="edit_description" name="edit_description"></textarea>
                            </div>
                            <div class="form-group">
                                <label for="edit_price">Price:</label>
                                <input type="number" step="0.01" class="form-control" id="edit_price" name="edit_price" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" name="update_service">Update Service</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Delete Modal -->
        <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form action="" method="POST">
                        <div class="modal-header">
                            <h5 class="modal-title" id="deleteModalLabel">Delete Service</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <p>Are you sure you want to delete this service?</p>
                            <input type="hidden" name="delete_id" id="delete_id">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-danger" name="delete_service">Delete Service</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Display Services for Editing/Deletion -->
        <h3>Services List</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Service Name</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql_services = "SELECT * FROM services WHERE userid='$user_id'";
                $result_services = $conn->query($sql_services);
                if ($result_services->num_rows > 0) {
                    while ($row_service = $result_services->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row_service['servicename'] . "</td>";
                        echo "<td>" . $row_service['description'] . "</td>";
                        echo "<td>" . $row_service['price'] . "</td>";
                        $status = $row_service['status'];
                        echo "<td>";
                        if ($status == 0) {
                            echo "<div style='color:red;'>Pending</div>";
                        } elseif ($status == 1) {
                            echo "<div style='color:black;'>Activated</div>";
                        } else {
                            echo "Unknown Status";
                        }
                        echo "</td>";
                        echo "<td>";
                        echo "<button type='button' class='btn btn-primary' data-toggle='modal' data-target='#editModal' data-editid='" . $row_service['serviceid'] . "' data-servicename='" . $row_service['servicename'] . "' data-description='" . $row_service['description'] . "' data-price='" . $row_service['price'] . "'>Edit</button>";
                        echo "&nbsp;";
                        echo "<button type='button' class='btn btn-danger' data-toggle='modal' data-target='#deleteModal' data-deleteid='" . $row_service['serviceid'] . "'>Delete</button>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No services found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        $('#editModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var edit_id = button.data('editid');
            var servicename = button.data('servicename');
            var description = button.data('description');
            var price = button.data('price');

            var modal = $(this);
            modal.find('.modal-title').text('Edit Service');
            modal.find('#edit_id').val(edit_id);
            modal.find('#edit_servicename').val(servicename);
            modal.find('#edit_description').val(description);
            modal.find('#edit_price').val(price);
        });

        $('#deleteModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var delete_id = button.data('deleteid');

            var modal = $(this);
            modal.find('.modal-title').text('Delete Service');
            modal.find('#delete_id').val(delete_id);
        });
    </script>
</body>
</html>
